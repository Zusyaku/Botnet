<?php

	if(!defined('GRANTED')) die;

?>


		<center>
			<b> 
				AnnLoad 2011 [sw] team
			</b>
		</center>


	</body>


</html>