<?php

	if(!defined('GRANTED')) die;

?>

<html>

<head>
	
	<title>Annload 2011 [sw] team</title>
	
	<link rel="stylesheet" type="text/css" href="style.css">
	
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">

</head>


<body>



<p align="center">
	<img border="0" src="annloader.png">
</p>

