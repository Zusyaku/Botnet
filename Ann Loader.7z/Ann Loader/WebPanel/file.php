<?php

error_reporting(0);

$file = "";
if (isset($_GET['upd'])) $file = "update";
if (isset($_GET['del'])) $file = "deleter";

echo file_get_contents("data/{$file}.dat");

?>