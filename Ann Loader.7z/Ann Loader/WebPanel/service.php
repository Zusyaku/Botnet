<?php

error_reporting(0);

include 'include/titles.php';

$ordtm = intval($_GET['t']) or die;
$order = $_GET['o'] or die;

$orders = file('data/orders.dat');

while (current($orders)) {
	$ORDER = unserialize(current($orders));
	if ($order==$ORDER['name'] and $ordtm==$ORDER['time']) {
		$answer = file_get_contents('data/'.$ORDER['id'].'i.dat');
		$count = substr_count($answer, "\n");
		$answer = explode("\n", $answer);
		while (current($answer)) {
			$temp = explode(':',current($answer));
			$countries[$temp[2]]++;
			next($answer);
		}





echo '<style>
body {color:#96A69A;background-color:#202020;}
</style>
<table width=100% style="font-family:Tahoma;font-size:8pt;">
<tr><td colspan=3 align=center><b>��������� ���������� �� ������: ['.$ORDER['name'].'] '.$ORDER['time'].'</b></td></tr>
<tr><td colspan=3>&nbsp;</td></tr>
<tr><td colspan=3><hr>
<table width=100% style="font-family:Tahoma;font-size:8pt;">
<tr align=center>
<td width=10%><b>�����</b></td>
<td width=10%><b>������</b></td>
<td width=30%><b>����</b></td>
<td><b>������</b></td>
</tr>
<tr align=center>
<td>'.$ORDER['need'].'</td>
<td>'.$count.'</td>
<td>'.$ORDER['url'].'</td>
<td style="font-size:9px;">';

if (substr_count($ORDER['countries'], ' ')==252) echo '��� ������';
else {
	include 'include/titles.php';
	$tmp = explode(' ', $ORDER['countries']);
	foreach ($tmp as $value) echo $COUNTRY_CODE[$value].' ';
}

echo '</td>
</tr>
</table>
</td></tr>
<tr><td colspan=3 align=center><hr><b>������</b></td></tr>
';
arsort($countries);
while (current($countries)) {
	echo '<tr><td width=43% align=right>'.current($countries).' -</td>
<td width=7% align=right>('.round(current($countries)/$count*100, 2).'%) -</td>
<td align=left>['.$COUNTRY_CODE[key($countries)].'] '.$COUNTRY_NAME[key($countries)].'</td></tr>
';
	next($countries);
}
echo '</table>';





		die;
	}
	next($orders);
}

?>