<?php

$num = 500;

$dead = 7;

$delay = 71;

$login = 'admin';

$passw = '21232f297a57a5a743894a0e4a801fc3';

?>
