<?php

$db_host = 'localhost';

$db_name = 'annloader';
$db_user = 'root';

$db_pass = '1337';

?>