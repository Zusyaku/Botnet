Create SQL db, import db.sql with PHPmyAdmin
edit \include\mysql.php with all your information
edit \include\config.php with your desired login user and password

Login to Admin Panel at \admin\index.php, Direct victims to g.php 