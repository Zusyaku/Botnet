<?php
@session_start();
class sqlImport {
    
    //Collect variables
    function sqlImport ($host, $user,$pass, $ArchivoSql) {
    $this -> host = $host;
    $this -> user = $user;
    $this -> pass = $pass;
    $this -> ArchivoSql = $ArchivoSql;
    }

    //Connect to the database
    function dbConnect () {
    $con = mysql_connect($this -> host, $this -> user, $this -> pass);
    }
    
    //Volcamos data
    function import () 
    {   
    
           if ($this -> con !== false) 
           {

         $f = fopen($this -> ArchivoSql,"r+");
        $sqlFile = fread($f, filesize($this -> ArchivoSql));
         $sqlArray = explode(';', $sqlFile);

             foreach ($sqlArray as $stmt) 
             {
                   if (strlen($stmt) > 3)
                   {
                    $result = mysql_query($stmt);
                      if (!$result)
                      {
                     $CodigoError = mysql_errno();
                     $TextoError = mysql_error();
                     break;
                      }
              
                }
        
              }
          }
          
    }
    
    function ShowErr () 
    {    
           if ($this -> CodigoError == 0)
           {
           $Salida ["exito"] =  1;
        }else{
        $Salida ["exito"] =  0;           
        $Salida ["errorCode"] = $this -> CodigoError;
        $Salida ["errorText"] =  $this -> TextoError;
           }

    return $Salida;
    }

} 

if( isset($_SESSION['msj']) ) { unset($_SESSION['msj']); }
$_SESSION['msj'] = "" ;

$Pass = substr(sprintf('%o', @fileperms('Configs/Pass.txt')), -4);
$Configs2 = substr(sprintf('%o', @fileperms('Configs/Configs.txt')), -4);
$Sql = substr(sprintf('%o', @fileperms('db.sql')), -4);


$Perm = "0777" ;


if( $Pass == $Perm && $Configs2 == $Perm && $Sql == $Perm  ){
	if( isset($_POST['servidor']) ){
		$usuario = $_POST['usuario'] ;
		if( !@mysql_connect ($_POST['servidor'] , $_POST['usuario'] , '' . $_POST['password']) ){
			$_SESSION['msj'] = "Unable to connect to mysql server" ;
		} else {
			if( !@mysql_select_db($_POST['dbase']) ){
				$_SESSION['msj'] = "Could not connect database wing." ;
			} else {
				$newImport = new sqlImport ($_POST['servidor'], $_POST['usuario'], $_POST['password'], "db.sql");
				$newImport -> import ();
				
				$UsersTxt = @file("Configs/Pass.txt");
				for($i=0; $i<count($UsersTxt); $i++){
					$Users .= $UsersTxt[$i] ;
				}
				$Pass = str_replace("User" , $_POST['user'] , $Users);
				$Pass = str_replace("Passw" , $_POST['pass'] , $Pass);
				$O = @fopen("Configs/Pass.php" , "a+");
				@fwrite($O , $Pass);
				@fclose($O);
				
				$ConfigsTxt = @file("Configs/Configs.txt");
				for($i=0; $i<count($ConfigsTxt); $i++){
					$Configs .= $ConfigsTxt[$i] ;
				}
				$Configs = str_replace("localhost" , $_POST['servidor'] , $Configs);
				$Configs = str_replace("root" , $usuario , $Configs);
				$Configs = str_replace("password" , $_POST['password'] , $Configs);
				$Configs = str_replace("DatBase" , $_POST['dbase'] , $Configs);
				$O = @fopen("Configs/Configs.php" , "a+");
				@fwrite($O , $Configs);
				@fclose($O);
				
				@unlink("Configs/Pass.txt");
				@unlink("Configs/Configs.txt");
				@unlink("db.sql");
				@unlink("install.php");
				echo '<meta http-equiv="refresh" content="0;URL=index.php">' ; 
			}
		}
	}
} else {
	$_SESSION['msj'] = "You need to CHMOD permissions to 0777 for following files.<br />" ;
	$_SESSION['msj'] .= "Configs/Configs.txt.<br />" ;
	$_SESSION['msj'] .= "Configs/Pass.txt.<br />" ;
	$_SESSION['msj'] .= "db.sql.<br />" ;
}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/tr/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>[vOlk-Botnet]v4.0 Install Web-Panel</title>
		<link REL="shortcut icon" HREF="./archivos/imagen/favicon.ico"> 
		 <style type="text/css">
  a:link {
        color: rgb(0,64,192);
}
a:visited {
        color: rgb(128,128,128);
}
a:active {
        color: rgb(0,192,128);
}
body {
	font-family: Verdana;
    font-size: 10px;
	background-image: url('archivos/imagen/bg.gif');
}
input, textarea {
	border: 1px;
	border-color: #333333;
	border-style: solid;
    font-family: Verdana;
    font-size: 10px;
}
table {
        font-family: Verdana;
        color: rgb(102,102,102);
        font-size: 10px;
		border: 0;
}
h1 {
        font-family: Verdana;
        color: rgb(102,102,102);
        font-size: 24 px;
        margin: 0px, 0px, 0px, 0px;
		padding: 0px, 0px, 0px, 0px;
		font-weight: normal;
}
h2 {
        font-family: Verdana;
        color: rgb(102,102,102);
        font-size: 16 px;
        margin: 0px, 0px, 0px, 0px;
		padding: 0px, 0px, 0px, 0px;
		font-weight: normal;
}
h3 {
        font-family: Verdana;
        color: rgb(102,102,102);
        font-size: 12 px;
        margin: 0px, 0px, 0px, 0px;
		padding: 0px, 0px, 0px, 0px;
		font-weight: normal;
}
.comment {
        font-family: Verdana;
        color: rgb(128,128,128);
        font-size: 10px;
        margin: 0;
		padding: 0;
		font-weight: normal;
}
.error {
        font-family: Verdana;
		font-weight: bold;
		color: RGB(255, 0, 0);
		font-size: 10px;
}
.warning {
        font-family: Verdana;
		font-weight: bold;
		color: RGB(225, 225, 0);
		font-size: 10px;
}
.ok {
        font-family: Verdana;
		font-weight: bold;
		color: RGB(0, 225, 0);
		font-size: 10px;
}
.disabled {
	color: #BBBB33;
}
.div_main {
    background: black url(archivos/imagen/sq.jpg);
	width: 740px;
	border: solid 1px black;
	padding: 10px;
	margin: 0px;
}
.div_smmain {
    background-color: #00FF00;
	width: 500px;
	border: solid 1px black;
	padding: 10px;
	margin: 0px;
}
.div_beta {
	position: absolute;
	top: 0px;
	right: 0px;
}



.pointer{cursor:pointer;}


a{
	text-decoration:underline;
	cursor:pointer;
}
</style>
<body>

		<script type="text/javascript">
        	function Install(){
			

				var user_1 = document.getElementById('user').value;
				var pass_1 = document.getElementById('pass').value;
				var server = document.getElementById('servidor').value;
				var user = document.getElementById('usuario').value;
				var pass = document.getElementById('password').value;
				var dbase = document.getElementById('dbase').value;


				var __confirm = confirm("Sure to save the data?.");
				if( !__confirm ){ return false ; }

							
				if(server == ''){
					cadena = 'Please enter the mysql server.' ;
					document.getElementById('mensajes').innerHTML = cadena ;
					return false ;
				}
				
				if(user == ''){
					cadena = 'Please enter the mysql user.' ;
					document.getElementById('mensajes').innerHTML = cadena ;
					return false ;
				}
				if(pass == ''){
					cadena = 'Please enter the mysql pass.' ;
					document.getElementById('mensajes').innerHTML = cadena ;
					return false ;
				}

				
				if(dbase == ''){
					cadena = 'Please enter the database.' ;
					document.getElementById('mensajes').innerHTML = cadena ;
					return false ;
				}
				
				if(user_1 == ''){
					cadena = 'Please enter the Administrator user.' ;
					document.getElementById('mensajes').innerHTML = cadena ;
					return false ;
				}
				
				
				if(pass_1 == ''){
					cadena = 'Please enter the Administrator password.' ;
					document.getElementById('mensajes').innerHTML = cadena ;
					return false ;
				}
				
				
				
				
				return true ;
			}
        </script>
        
		<p>&nbsp;</p>
		<p>&nbsp;</p>
		<p align="center">&nbsp;</p>
        
	</head>
		<body>

<div align="center">
<form id='frm_findinfo' onSubmit="return Install();" method="post">
<table width="700" align="center" background="archivos/imagen/bg.gif" style="border:1px solid #808080;">
  <tr>
  <td width="" valign="top">   
<table width="692">
            
<tr><td height="274" style="color:#c6c4c5;" id="estadisticas2" background="archivos/images/bg.gif">

<center>
  <div class="banner">
<center><span  style="color:#FF9900"><img src="archivos/imagen/4_04.jpg" alt="Install" width="336" height="85" border="0"></span><table width="520">
	<tr>
		<td width="206" align="left">&nbsp;
		</td>
		<td width="304" align="center">&nbsp;
		</td>
	</tr>
	<tr>
		<td align="left">
		<div align="left">Create administrator user:</div></td>
		<td width="304" align="center">
		<div align="justify">&nbsp;<input name="user" type="text" style="border: 1px solid #FFFFFF;width:144; height:21; font-size:8pt; font-family:Tahoma; color:#FF9900; background-color:#000000" value="" size="23" id="user">
		</div></td>
	</tr>
	<tr>
		<td align="left">
		<div align="left"><span id="result_box" class="short_text" lang="en">
			<span class="hps">Create</span> <span class="hps">administrator 
			password:</span></span></div></td>
		<td width="304" align="center">
		<div align="justify">&nbsp;<input name="pass" type="text" style="border: 1px solid #FFFFFF;width:144; height:21; font-size:8pt; font-family:Tahoma; color:#FF9900; background-color:#000000" value="" size="23" id="pass">
		</div></td>
	</tr>
	<tr>
		<td align="left">
		<div align="left">MYSQL Server Hosting:</div></td>
		<td width="304" align="center">
		<div align="justify">&nbsp;<input name="servidor" type="text" style="border: 1px solid #FFFFFF;width:144; height:21; font-size:8pt; font-family:Tahoma; color:#FF9900; background-color:#000000" value="" size="23" id="servidor">
		</div></td>
	</tr>
	<tr>
		<td align="left">
		<div align="left">MYSQL Server User:</div>		</td>
		<td width="304" align="center">
		<div align="justify">&nbsp;<input name="usuario" type="text" style="border: 1px solid #FFFFFF;width:144; height:21; font-size:8pt; font-family:Tahoma; color:#FF9900; background-color:#000000" value="" size="23" id="usuario">
		</div></td>
	<tr>
		<td align="left">
		MYSQL Server Pasw:</td>
		<td width="304" align="center">
		<div align="justify">&nbsp;<input name="password" type="text" style="border: 1px solid #FFFFFF;width:144; height:21; font-size:8pt; font-family:Tahoma; color:#FF9900; background-color:#000000" value="" size="23" id="password">
		</div></td></tr>
	<tr>
		<td align="left" height="23">
		<div align="left">MYSQL Server db:</div>		</td>
		<td width="304" align="center" height="23">
		<div align="justify">&nbsp;<input name="dbase" type="text" style="border: 1px solid #FFFFFF;width:144; height:21; font-size:8pt; font-family:Tahoma; color:#FF9900; background-color:#000000" value="" size="23" id="dbase">
		</div></td></tr>
	<tr>
		<td>
		<div align="center"></div></td>
		<td width="304">
		<div align="left"><br />
			<input type="submit" value="Instalar BotPanel" name="enviar" style="font-family: Tahoma; font-size: 14pt; border: 1px solid #FFFFFF; color:#808080; background-color:#000000">
		</div>		</td>
	</tr>
</table>
</center>
</div>
  <span  id="mensajes" style="color:#FF9900"><?php echo $_SESSION['msj'] ; ?></span><br>
</center>

</td></tr>
</table></td></tr>
</table>
		<p align="center">&nbsp;</p>
    
    
    
<p align="left"><font color="#808080">[vOlk-Botnet]v4.0 Code by vOlk</font></p>
    
    
    
</body>
</html>

