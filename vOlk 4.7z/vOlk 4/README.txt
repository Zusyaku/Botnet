-Upload all files
-CHMOD the following files to 0777: \configs\Configs.txt,\configs\Pass.txt, and db.sql.
-Create Mysql db.
-Visit \install.php and follow instructions.

Note: Logout button doesn't seem to work, you'll have to clear the cookies.