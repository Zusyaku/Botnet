<?php
mysql_connect('localhost','root','');
mysql_select_db('aldi');

//Sekunden f�r Interval
$seconds = 31;

//Login
$user = 'till7';
$pass = 'aldiftw';

//ON, OFF - CHECK
$time_now = date('Y-m-d H:i:s');		
$query = "UPDATE bots SET status = 0,socksaktiv = 0 WHERE DATE_SUB('$time_now', INTERVAL ".$seconds." SECOND) > time";
mysql_query($query) OR die(mysql_error());
?>