<?php
session_start(); 
	
if(!$_SESSION['aldisess1337']) {
    header('Location: login.php'); exit();
}
?>