<?php
session_start();

include('inc/config.php');

//$_SESSION['aldisess1337'] = false;
$err = '';
if(isset($_SESSION['aldisess1337'])) { echo '<meta http-equiv="refresh" content="0; URL=index.php?id=stats">'; }

if(isset($_POST['login'])){
	$usr = $_POST['usr'];
	$pwd = $_POST['pwd'];
	
	if($usr == $user && $pwd == $pass){
		$_SESSION['aldisess1337'] = true;	
		header('Location: index.php?id=stats');
	}else{
		$err = 'Login error';
	}
}
?>

<link rel="stylesheet" type="text/css" href="login.css"/>
<div id="logo"></div>
<div id="wrapper">

<div id="box">C&C Aldi Server</div>
<div id="login">
  <form action="login.php" method="post">
	<p><label for="usr">Benutzer: </label><input type="text" name="usr" id="usr" /></p>
	<label for="pwd">Passwort: </label><input type="password" name="pwd" id="pwd" />
		
	<p><input type="submit" name="login" value="anmelden" class="btn" /></p>
	<b class="err"><?php echo $err; ?></b>
  </form>
</div>
</div>