<?php require_once('inc/session.php'); require_once('inc/body.php'); require_once('inc/config.php'); require_once('funcs/safe.php'); ?>

<h3>Pages</h3>
<form action="settings.php" method="post">
	<p>Bots per page <input type="text" name="perpage" class="tb" value="<?php echo pages(); ?>" />
	<input type="submit" name="save_perpage" class="button" value="Save" /></p>
</form>

<?php

if(isset($_POST['save_perpage'])){
	$pages = safe_xss($_POST['perpage']);
	mysql_query("UPDATE settings Set pages = '".safe_sql($pages)."'");
	
	echo '<meta http-equiv="refresh" content="0; URL=settings.php">';
}

//Pages
function pages(){
$ergebnis = mysql_query("SELECT * FROM settings");

	 while($row = mysql_fetch_array($ergebnis))
	{
		return safe_xss($row['pages']);
	}
}
	  
require_once('inc/footer.php');
?>