<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
        "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title>Brainbot :: Admin</title>
<link rel="SHORTCUT ICON" href="img/icons/favicon.ico" type="image/x-icon">
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<link rel="stylesheet" type="text/css" href="css/facebox.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script language="javascript" src="js/facebox.js"></script>
<script type="text/javascript" src="js/highcharts.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
<div id="wrapper">
<div id="header"></div>	
	<div id="navigation">
		<ul>
			<li><a href="index.php">Welcome</a></li>
			<li>#</li>
			<li><a href="list.php">List of bots</a></li>
			<li>#</li>
			<li><a href="mytasks.php">My tasks</a></li>
			<li>#</li>
			<li><a href="settings.php">Settings</a></li>
		</ul>
	</div>
		
<div id="content">