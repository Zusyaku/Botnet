<?php
//Edit data
$data = array('server' => 'localhost',
			  'user'   => '',
			  'pass'   => 'blahblah',
			  'db' 	   => 'brain');

//Connect interval [minutes]
$minutes = 1;

//Login
$username = 'admin';
$password = '123';

//Change nothing
mysql_connect($data['server'],$data['user'],$data['pass']);
mysql_select_db($data['db']);
?>