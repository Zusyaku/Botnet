</div>	
<div id="footer">&copy; Brainbot 2011 | valid xhtml</div>
</div>
</body>
</html>