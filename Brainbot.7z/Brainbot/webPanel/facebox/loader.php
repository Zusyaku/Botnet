<?php require_once('../inc/session.php'); require_once('../inc/config.php'); ?>

<!-- Loader -->
	<form action="mytasks.php" method="post">
		<p><label>Download URL</label><input type="text" class="tb" name="url" /></p>
		<p><label>Number of loads</label><input type="text" class="tb" name="loads" /></p>
		<p><label>Date / Time</label><input type="text" id="datetime_loads" name="datetime" class="tb" />&nbsp;<img src="img/icons/clock.png" onclick="document.getElementById('datetime_loads').value = '<?php echo date('Y-m-d H:i:s'); ?>';" /></p>

		<input type="submit" name="addtask_loads" class="button" value="Add task" />
	</form>
<!-- Loader -->