<?php 
	session_start(); 
	require_once('inc/config.php');
	
	if($_SESSION['login']) { header('Location: index.php'); exit(); }

	if(isset($_POST['login'])){
		$user = $_POST['user'];
		$pass = sha1(md5(htmlspecialchars($_POST['pass'])));
		
		if($user == $username && $pass == sha1(md5(htmlspecialchars($password)))){
				$_SESSION['login'] = true;
				$_SESSION['username'] = $user;
				header('Location: index.php');
		}else{
			$error = 'I\'m a noob';
		}
	}
?>

<link rel="stylesheet" type="text/css" href="css/style.css"/>

<form action="login.php" method="post">
	<p><label>User</label><input type="text" class="tb" name="user" value="<?php echo $error; ?>" /></p>
	<p><label>Pass</label><input type="password" class="tb" name="pass" value="<?php echo $error; ?>" /></p>
	<p><input type="submit" name="login" class="button" value="Login" /></p>
</form>