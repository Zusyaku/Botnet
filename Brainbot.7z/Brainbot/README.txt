Create SQL db
import brainbot.sql in phpmyadmin for the sql database
edit \inc\config.php with your details.