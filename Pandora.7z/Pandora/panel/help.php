<div class="content">
<center>Information</center>

1. Product Description<br>

From the creator of Dirt Jumper and Simple!<br>
DDoS Key System in 2012!<br>
new, universal ddos botnet Pandora!<br>
This unique product combines only the best moments from all the previously created versions.<br>
This bot is written with the participation of clients yuzayuschih previous version of the author.<br><br>

<strong>Yes, Pandora will come to you!</strong>
<br><br>

2.<i>Instruction Manual</i> <br>
This bot has five modes of attack.<br>
1. "HTTP min" requests over TCP, without receiving an answer. Connect is broken so that the server continues to wait until the client receives a response.
 In this Time is already running another query. So besides that is 100% load on apache, db, channel, and is set half-open connections, 
<br>
 2. "HTTP Download" Almost the same as the first method, but unlike him, this type of attack takes the answer, creating a different kind of load. 
 Namely: Employment konnekta, the traffic load on the Apache with the impact of information. 
 <br>
 3. "HTTP Combo" This method of attack combines the first and second. Boat in turn performs a request by the first method, the second one. 
 <br>
 4. "Socket Connect" But this method is written exclusively on the sockets.
 Boat performs connection to the server, and while he did not refuse to accept the information, the bot will send traffic. 
 port, you can specify any. 
 <br>
 5. "Max Flood" method which allows the hammer channel.  Executes queries with very large packages. 
 <br>
 attacks numbering starts with zero! 
 <br>
 At the bot has a system of time-outs. 
 In the box you need to specify the timeout in milliseconds. 
 Time-out is performed in each stream separately. 
 <br>
 In order to stop the attack you need to specify the number of zero flows.
<br>
 All methods support the possibility of attacks strike at the port. 
 The fourth method of attack beats only by IP. (If you specify a domain, it will determine the IP.) 
</div>