<?php
	error_reporting(0);
	$dbhost1="localhost";

	/* User database */
	$dbuname1="panda";

	/* Database Name */
	$dbname1="pandora";

	/* Password Database */
	$dbpass1="blahblah";

	/* GET Login */
	$GET_login="vfvfyz";

	/* Login */
	$login="admin";

	/* Password */
	$password="1234";

	/* Interval default (sec) */
	$timeout=60;
	if ($sokol=="1") {
		$ip=$_SERVER['REMOTE_ADDR'];
		if ($bdload!="1") {
			mysql_connect($dbhost1, $dbuname1, $dbpass1) or include"404.php";
			mysql_select_db($dbname1);
		}
	} else {
		include"404.php";
	}
?>