<?php

$plugname="Socks4";
$plugact="socks4";

?>