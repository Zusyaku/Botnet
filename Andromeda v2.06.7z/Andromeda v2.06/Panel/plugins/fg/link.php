<?php
$plugname="Formgrabber";
$plugact="fg";
?>