<?php // !!! don't edit this file, just open http://yourdomain.com/?act=install
$settings=array();
$settings['mysql_host']="localhost";
$settings['mysql_user']="root";
$settings['mysql_pass']="";
$settings['mysql_db']="andr10";
$settings['login']="a2c92df3c6fdc105194010e059f8ed8f";
$settings['rc4key']="a619d974658f3e749b2d88b215baea46";
$settings['reqrate']=1;
$settings['dead_limit']=7;
$settings['accept_new_installs']=1;
?>