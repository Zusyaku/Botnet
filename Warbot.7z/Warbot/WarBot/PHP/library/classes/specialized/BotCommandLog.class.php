<?php
	class BotCommandLog extends Base {
		public static $Table = "v_bots_command_log";
		public static $MasterTable = "bots_command_log";
		public function __construct($ID = false, $Row = false) {
			parent::__construct($ID, $this, $Row, self::$Table, self::$MasterTable);
		}
	}
?>