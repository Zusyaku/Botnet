<?php
	if (!function_exists("sign")) {
		function sign($x){
			return (int)((abs($x)-$x)? -1:$x>0);
		}
	}
?>