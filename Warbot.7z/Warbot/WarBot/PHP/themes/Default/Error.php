		<title>.:Warbot Error:.</title>
	</head>
	<body>
	<?php
		if (isset($Error))
			echo $Error;
		else
			echo "Hello Error!";
	?>
	