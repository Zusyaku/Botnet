<?php
	foreach ($Bots as $Bot) {
		echo $Bot->Get("Country") . ",";
	}
?>