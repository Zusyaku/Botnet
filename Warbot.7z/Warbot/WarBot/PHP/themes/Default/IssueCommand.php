<?php
	if (!empty($CommandID))
		echo $CommandID;
?>