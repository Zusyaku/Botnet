<?php
	try {
		$Auth = new Auth();
		$Auth->RequireSession();
		$Auth->Ajax();
		$Auth->Validate(false);
	} catch(Exception $e) {
		die("fuck u faggot azuisleet");
	}
	if(!isset($_GET['PageOffset'])) {
		$Override = array("LIMIT" => "0, 10");
	} else {
		$Override = array("LIMIT" => intval($_GET['PageOffset']) . ", 10");
	}
	$lBots = Bot::Find($Override);
	if(count($lBots) == 0 && isset($_GET['PageOffset'])) {
		echo "NO";
		exit();
	}
	$BotsInfo = array();
	foreach($lBots as $lBot) {
		$mInfo = array();
		$mInfo['ID'] = $lBot->Get('BotID');
		switch(trim($lBot->Get('OSVerMajor') . '.' .  $lBot->Get('OSVerMinor'))) {
			case '5.0':
				$mInfo['OS'] = "Windows 2000";
				break;
			case '5.1':
				$mInfo['OS'] = "Windows XP";
				break;
			case '5.2':
				$mInfo['OS'] = "Windows Server 2003";
				break;
			case '6.0':
				$mInfo['OS'] = "Windows Vista";
				break;
			case '6.1':
				$mInfo['OS'] = "Windows 7";
				break;
			case '7.0':
				$mInfo['OS'] = "Windows 7";
			case '7.':
				$mInfo['OS'] = "Windows 7";
			default:
				$mInfo['OS'] = $lBot->Get('OSVerMajor') . '.' .  $lBot->Get('OSVerMinor');
		}
		$mInfo['IP'] = $lBot->Get("IP");
		$mInfo['Status'] = (time() - WARBOT_INTERVAL < $lBot->Get('LastReq_Date')) ? ("YES") : ("NO");
		$mInfo['Last'] = date("H:i:s", $lBot->Get('LastReq_Date'));
		$mInfo['Country'] = $lBot->Get('Country');
		$mInfo['CountryImg'] = strtolower($lBot->Get('Country'));
		$BotsInfo[] = $mInfo;
	}
	if(isset($_GET['PageOffset'])) {
		?>
		<tr>
			<th>ID</th>
			<th>Country</th>
			<th>OS</th>
			<th>IP</th>
			<th>Online</th>
			<th>Last Ping</th>
		</tr>
		<?php
		foreach($BotsInfo as $BotInfo) {
				$HTML = "
				<tr class=\"Stats_BotEntry\">
				<td>{$BotInfo['ID']}</td>
				<td><img src=\"themes/Default/img/flags/{$BotInfo['CountryImg']}.png\" alt=\"{$BotInfo['Country']}\" height=\"11px\" width=\"16px\" /></td>
				<td>{$BotInfo['OS']}</td>
				<td>{$BotInfo['IP']}</td>
				<td>{$BotInfo['Status']}</td>
				<td>{$BotInfo['Last']}</td>
				</tr>
";			
			echo $HTML;
		}
		exit();
	}
	
?>
	<div id="Stats_Wrapper" style="text-align:center;display:block;">
	<table id="Stats_Table">
		<tr>
			<th>ID</th>
			<th>Country</th>
			<th>OS</th>
			<th>IP</th>
			<th>Online</th>
			<th>Last Ping</th>
		</tr>
		<?php
			foreach($BotsInfo as $BotInfo) {
				$HTML = "
				<tr class=\"Stats_BotEntry\">
				<td>{$BotInfo['ID']}</td>
				<td><img src=\"themes/Default/img/flags/{$BotInfo['CountryImg']}.png\" alt=\"{$BotInfo['Country']}\" height=\"11px\" width=\"16px\" /></td>
				<td>{$BotInfo['OS']}</td>
				<td>{$BotInfo['IP']}</td>
				<td>{$BotInfo['Status']}</td>
				<td>{$BotInfo['Last']}</td>
				</tr>
";			
				echo $HTML;
			}
		?>
	</table>
	</div><br />
	<span style="position:absolute;left:4px;bottom:1px;" onclick="StatsPrevious()">Previous</span>
	<span style="position:absolute;right:4px;bottom:1px;" onclick="StatsNext()">Next</span>
	<span style="position:absolute;right:50%;left:50%;bottom:1px;" onclick="showWindow('tasks')">Tasks</span>