#################################################
# Elite Loader v3.0 #
# #
# � oded by [PRO] MAKE.ME TeaM: P #
# #
# To BBC and McAfee: #
# Project to capture The World #
# In the implementation. #
# #
# You lose! Who next?  #
# #
#################################################

- The rights to the folder CHMOD:
/ Load / 0777
/ Config.php 0777

- In the browser, run install.php, enter data, perform installations.
- Remove install.php
- Put the right to config.php 0644
- Go to admin panel under our username and password.

Support:
There will be, the project is closed. Say thank you to those customers
who helped put laoder in public on the second day of sales.
I found 3 different Bildera, nicks and icq will be Black, but not now. ;)