<?php
# Admin Login
define('ROOT_LOGIN','admin');
# Admin Password
define('ROOT_PASSW','pass');
# Language ru, en, de
define('LANGUAGE', 'en');
define('DB_USER','root');
define('DB_PASS','');
define('DB_NAME','chimera');
define('PREFIX','elite');
?>