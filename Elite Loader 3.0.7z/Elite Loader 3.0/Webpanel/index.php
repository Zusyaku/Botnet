<?php
Header('Location: http://www.google.com');
die();
?>