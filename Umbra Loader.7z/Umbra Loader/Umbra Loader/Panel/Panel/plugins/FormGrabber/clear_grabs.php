<?php
include('../../auth.php');
include("../../inc/config.php");
require_once("../../JSON.php");
$sql = "TRUNCATE TABLE `lst_formgrabber`;";  
$res = mysql_query($sql);
die("");
?>