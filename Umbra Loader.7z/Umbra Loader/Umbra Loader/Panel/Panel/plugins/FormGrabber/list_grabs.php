<?php
include('../../auth.php');
include("../../inc/config.php");
require_once("../../JSON.php");
$sql = "SELECT * FROM `lst_formgrabber` WHERE 1;";  
$res = mysql_query($sql);
$nbrows = 0;
if(mysql_num_rows($res)>0) {
    while($rec = mysql_fetch_array($res)) {
            $nbrows = $nbrows + 1;
            $arr[] = $rec;
    }
    $jsonresult = json_encode($arr);
    echo '{"results":'.$jsonresult.', "total":"'.$nbrows.'"}';
} else {
    echo '({"total":"0", "results":""})';
}
die("");
?>