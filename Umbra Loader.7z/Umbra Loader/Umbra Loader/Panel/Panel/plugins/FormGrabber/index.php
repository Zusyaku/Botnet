<?php include('../../auth.php'); ?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <title>Umbra Loader</title>
    <link rel="stylesheet" type="text/css" href="../../../resources/css/ext-all.css" />
 	<script type="text/javascript" src="../../../adapter/ext/ext-base.js"></script>
    <script type="text/javascript" src="../../../ext-all.js"></script>
    <link rel="Stylesheet" type="text/css" href="../../style.css" media="screen" />
</head>
<body>
    <div class="root">
        <div id="header"></div>
    </div>
    <script type="text/javascript" src="socksproxy.js"></script>
</body>
</html>
