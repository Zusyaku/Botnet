<?php
##SQL DB Information
$host="mysql.mysite.com";
$user="sql1342";
$pass="blahblah";
$base="yzfweflk";
##Admin Page Login
$login="admin";
$password="1234";
?>