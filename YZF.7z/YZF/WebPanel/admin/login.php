<?php
include "cfg.php";
if (isset($_POST['password']) && isset($_POST['login']))
	{
		if ($_POST['password'] == $password && $_POST['login'] == $login)
		{
			SetCookie("YZF",md5($password),time()+600);
			header('Location: index.php');
		}
		else
		{
		echo '<html><table><form method="POST" name="adminlogin" action="b_new.php"><tr><td>Login Incorrect.</td></tr><tr><td><input type="text" name="login" value="admin" //><//td><//tr><tr><td><input type="password" name="password" value="" //><//td><td><input type="submit" value="Submit" //><//td><//tr><//table><//form><//html>';
		}
	}
else
	{
		echo '<html><table><form method="POST" name="adminlogin" action="b_new.php"><tr><td><input type="text" name="login" value="admin" //><//td><//tr><tr><td><input type="password" name="password" value="" //><//td><td><input type="submit" value="Submit" //><//td><//tr><//table><//form><//html>';
	}
?>
