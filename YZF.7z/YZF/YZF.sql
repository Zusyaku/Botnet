CREATE TABLE IF NOT EXISTS `bots` (
  `ip` text NOT NULL,
  `hwid` int(11) NOT NULL,
  `os` text NOT NULL,
  `time` int(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
