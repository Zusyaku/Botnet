<div align="center" style="margin-top:5px;">
	<span style="font-size:0.8em;">
		VertexNet - Loader coded by DarkCoderSc (PHP/C++)<br/>
		DarkCoderSc Software � since 2006<br/>
		<a href="http://www.unremote.org/">unremote.org</a>
	</span>
</div>