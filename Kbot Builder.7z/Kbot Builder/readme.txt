default login : 

trojanforge : trojanforge

Pass is sha1 crypt in db 