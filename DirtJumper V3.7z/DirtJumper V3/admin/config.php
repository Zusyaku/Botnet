<?php
error_reporting(0);
$dbhost="localhost";
$dbuname="djadm";
$dbname="j";
$dbpass="blahblah";
$GET_login="demo";
$login="admin";
$password="blahblah";
$interval="120";
if ($sokol=="1") {
$ip=$_SERVER['REMOTE_ADDR'];
mysql_connect($dbhost, $dbuname, $dbpass) or include"404.php";
mysql_select_db($dbname);
} else {
include"404.php";
}
?>