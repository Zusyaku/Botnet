<?php

require("./inc/cfg.php");
require("./inc/funcs.php");

$dbase = new dbClass();

$id = $_GET["id"];

if(!isset($_SERVER['PHP_AUTH_USER']) || $_SERVER['PHP_AUTH_USER'] !== $config["guest"] || $_SERVER['PHP_AUTH_PW'] !== $config["gpass"])
{
	header('WWW-Authenticate: Basic realm="Guest?"');
	header('HTTP/1.0 401 Unauthorized');
	exit;
}

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<title>Guest Statistic</title>
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>
<div class="main">
		<div class="header"></div>
		<div class="menu">
		<a href=""> >> STATS << </a>
		</div>
		<div class="data">	
<?php
if (!empty($id)) {
echo '<table cellpadding="3" cellspacing="0" align="center" cols="9" width="550px">
<tr>
<td align="center" colspan="8">
<h3 style="margin-top:20px;margin-bottom:20px;">Statistic of your task</h3>
</td>
</tr>
<tr>
<td align="center" style="width:25px;"><b>ID</b></td>
<td align="center" style="width:50px;"><b>Size</b></td>
<td align="center" style="width:130px;"><b>Date</b></td>
<td align="center" style="width:50px;"><b>Loads</b></td>
<td align="center" style="width:50px;"><b>Runs</b></td>
<td align="center" style="width:70px;"><b>Limit</b></td>
<td align="center" style="width:95px;"><b>URL</b></td>
<td align="center" style="width:30px;"><b>GEO</b></td>
<td align="center" style="width:50px;"><b>DLL</b></td>
</tr>'.allgexe($id).'</table>';
} else {
echo "Fuck Yeah!!!";
}

?>
		</div>
		<div class="footer"><p>Smoke Bot � 2012</p></div>
</div>
</body>
</html>