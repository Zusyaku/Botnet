-Upload all panel files
-Creat sql db
-Edit /index.php with db details

-Login to admin panel at /index.php with the default login (Strike:Strike)
-Once logged in, the tables will be created automatically.
-To change the admin login, edit the Admin table of the database.