<html>
    <head>
        <title>ip</title>
    </head>
    <body>
    <?php
        echo $_SERVER['REMOTE_ADDR'];
    ?>
    </body>
</html>
