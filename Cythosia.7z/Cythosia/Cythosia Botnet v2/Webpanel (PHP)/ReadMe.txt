Edit the Admin Password in admin/index.php
Edit all other configs in admin/inc/conf.php

Run dump.sql in your phpmyadmin

Cheers... Post.Mort3m