<?php
	// Config.php	
	
	// Times
	$time_on = (15*60)+15;			// User session timeout in seconds
		
	// MySQL
	$mysql_server = "localhost";
	$mysql_user = "";
	$mysql_pw = "";
	$mysql_db = "";
	$link = mysql_connect($mysql_server, $mysql_user, $mysql_pw);
	mysql_select_db($mysql_db, $link);
?>