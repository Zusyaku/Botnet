<?php
	session_start();
	if(!isset($_SESSION['hydra_loggedin']) && $_SESSION['hydra_loggedin'] != 1)
	{
		header("Location: http://www.google.com");
	}
	include("inc/config.php");
	include("inc/funcs.php");
	
	$query = mysql_query("
	SELECT t.*, (SELECT count(*) FROM hydra_victims WHERE taskID=t.taskID) AS vics,
	(SELECT count(*) FROM hydra_task_done WHERE taskID=t.taskID) AS done FROM hydra_tasks AS t WHERE t.time <= '".time()."' AND (t.elapsed > '".time()."' OR (t.elapsed=0 AND (SELECT count(*) FROM hydra_task_done WHERE taskID=t.taskID)<bots))
	ORDER BY t.taskID DESC
	");
	
	$table = '<div class="padding"><h2>Current Tasks</h2>';
	
	$table .= '<table style="margin: 5px; width: 99%;" class="smalltable"><tr>
	<th style="width:20px">&nbsp;</th>
	<th>Command</th>
	<th>Start Time</th>
	<th>Run Until</th>
	<th>Bots</th>
	</tr>';
	
	
	
	while($ds = mysql_fetch_array($query)) {
		$table .= '<tr><td>#'.$ds['taskID'].'</td><td><a onClick="showSpecificTask('.$ds['taskID'].');" href="#"><b>'.$ds['command'].'</b></a></td><td>'.date("d.m.Y H:i", $ds['time']).'</td><td>'.($ds['elapsed'] > 0 ? date("d.m.Y H:i", $ds['elapsed']) : '&nbsp;').'</td><td>'.($ds['elapsed'] == 0 ? $ds['done'].'/' : '').$ds['bots'].'</td></tr>';
	}
	$table .= '</table>';

	$query2 = mysql_query("
	SELECT t.*, (SELECT count(*) FROM hydra_victims WHERE taskID=t.taskID) AS vics,
	(SELECT count(*) FROM hydra_task_done WHERE taskID=t.taskID) AS done FROM hydra_tasks AS t WHERE t.time > '".time()."' OR (t.elapsed < '".time()."' AND t.elapsed != 0) OR (t.elapsed=0 AND (SELECT count(*) FROM hydra_task_done WHERE taskID=t.taskID)>=bots)
	ORDER BY t.taskID DESC
	");

	$table .= '<h2>Future/Done Tasks</h2>';
	
	$table .= '<table style="margin: 5px; width: 99%;" class="smalltable"><tr>
	<th style="width:20px">&nbsp;</th>
	<th>Command</th>
	<th>Start Time</th>
	<th>Run Until</th>
	<th>Bots</th>
	</tr>';

	while($ds=mysql_fetch_array($query2)) {
		$table .= '<tr><td>#'.$ds['taskID'].'</td><td><a onClick="showSpecificTask('.$ds['taskID'].');" href="#"><b>'.$ds['command'].'</b></a></td><td>'.date("d.m.Y H:i", $ds['time']).'</td><td>'.($ds['elapsed'] > 0 ? date("d.m.Y H:i", $ds['elapsed']) : '&nbsp;').'</td><td>'.($ds['elapsed'] == 0 ? $ds['done'].'/' : '').$ds['bots'].'</td></tr>';
	}
	$table .= '</table><br /></div>';
	echo $table;


?>