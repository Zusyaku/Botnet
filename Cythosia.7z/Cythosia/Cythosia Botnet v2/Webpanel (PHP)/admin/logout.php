<?php
	session_start();
	if(isset($_SESSION['hydra_loggedin']))
	{
		unset($_SESSION['hydra_loggedin']);
		header("Location: ../index.php");
	}
	else
	{
		header("Location: ../index.php");
	}
?>