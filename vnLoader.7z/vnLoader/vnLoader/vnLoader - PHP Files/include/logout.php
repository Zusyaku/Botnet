<?php
	//check if included in project
	if ( !defined ( 'vnLoader' ) ) header ( 'location: ../' );
	
	if ( isset ( $_POST['Logout'] ) )
		{
		session_unset (  );
		header ( 'location: ./' );
		}
	else
		{	
		$page .= '				Do you really want to log out?' . "\n";
		$page .= '				<br />' . "\n";
		$page .= '				<br />' . "\n";
		$page .= '				<form action="index.php?pid=7" method="post">' . "\n";
		$page .= '					<input type="hidden" name="Logout" value="Logout" />' . "\n";
		$page .= '					<input style="width: 20%;" type="submit" value="Logout" />' . "\n";
		$page .= '				</form>' . "\n";
		}
?>
