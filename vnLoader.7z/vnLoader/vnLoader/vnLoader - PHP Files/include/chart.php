<?php
	//check if included in project
	if ( !defined ( 'vnLoader' ) ) header ( 'location: ../' );
	//define variables

	$result = mysql_query("SELECT Count(id) FROM charts");
	while($rows = mysql_fetch_array($result))
		{
		$introws = $rows[0];
		}

	$bots_list = "";
	$date_list = "";
	
	$result = mysql_query("SELECT * FROM charts");
	while($rows = mysql_fetch_array($result)) 
		{
		$list = split('[.]', $rows['date']);
		$date = $list[0].".".$list[1];
		
		$bots_list .= $rows['bots'] . "; ";
		$date_list .= $date . "; ";
		}
		
	$bots_list = substr( $bots_list , 0 , -2 );
	$date_list = substr( $date_list , 0 , -2 );
			
	$page .= '				<br />' . "\n";
	$page .= '				<applet code="diagram.class" width="90%">' . "\n";
	$page .= '					<param name="bgcolor" value="248; 248; 248">' . "\n";
	$page .= '					<param name="xlabel" value="' . $date_list . ' "> ' . "\n";
	$page .= '					<param name="y0" value="' . $bots_list . ' "> ' . "\n";
	$page .= '					<param name="color0" value="#1b84ec">' . "\n";
	$page .= '					<param name="style0" value="LINE PLOP">' . "\n";
	$page .= '				</applet>' . "\n";
	$page .= '				<br />' . "\n";
?>