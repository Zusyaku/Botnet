<?php
	//check if included in project
	if ( !defined ( 'vnLoader' ) ) header ( 'location: ../' );

	//get users permissions
	$result = mysql_query("SELECT permission FROM userlist WHERE id = '" . $usr . "'");
	$rows = mysql_fetch_array($result);
	$permission = $rows['permission'];

	function instring($search , $string)
		{
		$instr = FALSE;
		$length = strlen ($string) - 1;
		for ($i = 0; $i <= $length ; $i++) 
			{
			if ( substr( $string , $i , 1) == $search ||  $string == "*" )
				{
				$instr = TRUE;
				break;
				}
			}
		return $instr;
	}
?>