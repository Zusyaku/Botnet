<?php
	//check if included in project
	if ( !defined ( 'vnLoader' ) ) header ( 'location: ../' );
	//Login

	$page .= '				<form action="index.php" method="post">' . "\n";
	$page .= '					Username:<br />' . "\n";
	$page .= '					<input type="text" name="user" style="width: 70%"></input><br />' . "\n";
	$page .= '					Password:<br />' . "\n";
	$page .= '					<input type="password" name="pass" style="width: 70%"></input><br /><br />' . "\n";
	$page .= '					<input type="submit" value="Login" style="width: 50%"></input><br /><br />' . "\n";
	$page .= '				</form>' . "\n";
?>