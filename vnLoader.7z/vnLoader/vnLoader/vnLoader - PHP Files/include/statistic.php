<?php
	//check if included in project
	if ( !defined ( 'vnLoader' ) ) header ( 'location: ../' );
	//set variables
	$online = '0';
	$offline = '0';
	$on24h = '0';
	$total = '0';
	$tasks = '0';
	$dead = '0';
	//count bots
	$count = mysql_query("SELECT * FROM botlist");
	while($rows = mysql_fetch_array($count)) 
		{
		$datum1 = $rows['LastPing'];
		$datum2 = strtotime( gmdate("M d Y H:i:s") );
	    	$diff = ($datum2 - $datum1);
		if ($diff <= '300') 
			{
			$online++;
			} 
		else 
			{
			$offline++;
			}
			
		if ($diff <= '86400') 
			{
			$on24h++;
			}
		if ($diff >= '259200') 
			{
			$dead++;
			}
			$total++;
		}
	//count tasks
	$count = mysql_query("SELECT * FROM commands");
	while($rows = mysql_fetch_array($count)) 
		{
		$tasks++;
		}
	//Stats
	$page .= '				<table class="center" width="50%">' . "\n";
	$page .= '					<tr>' . "\n";
	$page .= '						<td align="left" style="border-bottom: 1px dotted silver;">Total Bots:</td><td style="color: #1b84ec; border-bottom: 1px dotted silver;" align="right">' . $total . ' Bot(s)</td>' . "\n";
	$page .= '					</tr>' . "\n";
	$page .= '					<tr>' . "\n";	
	$page .= '						<td align="left" style="border-bottom: 1px dotted silver">Bots Online:</td><td style="color: #1b84ec; border-bottom: 1px dotted silver;" align="right">' . $online . ' Bot(s)</td>' . "\n";
	$page .= '					</tr>' . "\n";
	$page .= '					<tr>' . "\n";
	$page .= '						<td align="left" style="border-bottom: 1px dotted silver">Bots Offline:</td><td style="color: #1b84ec; border-bottom: 1px dotted silver;" align="right">' . $offline . ' Bot(s)</td>' . "\n";
	$page .= '					</tr>' . "\n";
	$page .= '					<tr>' . "\n";
	$page .= '						<td align="left" style="border-bottom: 1px dotted silver">Bots Total: (last 24 hours)</td><td style="color: #1b84ec; border-bottom: 1px dotted silver;" align="right">' . $on24h . ' Bot(s)</td>' . "\n";
	$page .= '					</tr>' . "\n";
	$page .= '					<tr>' . "\n";
	$page .= '						<td align="left" style="border-bottom: 1px dotted silver">Dead Bots: (3 Days expired)</td><td style="color: #1b84ec; border-bottom: 1px dotted silver;" align="right">' . $dead . ' Bot(s)</td>' . "\n";
	$page .= '					</tr>' . "\n";
	$page .= '					<tr>' . "\n";
	$page .= '						<td align="left" style="border-bottom: 1px dotted silver">Active Commands:</td><td style="color: #1b84ec; border-bottom: 1px dotted silver;" align="right">' . $tasks . ' Command(s)</td>' . "\n";
	$page .= '					</tr>' . "\n";
	$page .= '				</table>' . "\n";
	$page .= '				<br />' . "\n";

	$page .= '				<table class="center" width="100%" border="0">' . "\n";
	$page .= '				<col width="100*">' . "\n";
	$page .= '				<col width="100*">' . "\n";
	$page .= '				<tr style="color: #1b84ec"><td>Location</td><td>Operating System</td></tr>' . "\n";
	$page .= '				<tr style="vertical-align: top">' . "\n";
	$page .= '					<td>' . "\n";
	$page .= '						<table align="center" width="80%" border="0">' . "\n";
	$page .= '						<col width="100*">' . "\n";
	$page .= '						<col width="100*">' . "\n";

	$result = mysql_query("SELECT COUNTRY, Count(COUNTRY) AS n FROM botlist GROUP BY COUNTRY ORDER BY n DESC;");
	while($rows = mysql_fetch_array($result)) 
		{
		$page .= '							<tr><td align="center" style="border-bottom: 1px dotted silver"><img src="./images/flags/' . IPtoFlag($rows[0]) . '.GIF" style="vertical-align:center; border-bottom: 1px dotted silver;" /> ' . $rows[0] . '</td><td align="center" style="border-bottom: 1px dotted silver">' . $rows[1] . '</td></tr>' . "\n";
		}

	$page .= '						</table>' . "\n";
	$page .= '					</td>' . "\n";
	$page .= '					<td>' . "\n";
	$page .= '						<table align="center" width="80%" border="0">' . "\n";
	$page .= '						<col width="100*">' . "\n";
	$page .= '						<col width="100*">' . "\n";

	$result = mysql_query("SELECT OS, Count(OS) AS n FROM botlist GROUP BY OS ORDER BY n DESC;");
	while($rows = mysql_fetch_array($result)) 
		{
		$page .= '							<tr><td align="center" style="border-bottom: 1px dotted silver">' . $rows[0] . '</td><td align="center" style="border-bottom: 1px dotted silver">' . $rows[1] . '</td></tr>' . "\n";
		}

	$page .= '						</table>' . "\n";
	$page .= '					</td>' . "\n";
	$page .= '				</tr>' . "\n";
	$page .= '				</table>' . "\n";
	$page .= '				<br />' . "\n";
	include ( 'chart.php' );

	function IPtoFlag($Country) 
		{
		//http://www.it-academy.cc/article/1467/PHP:+Herkunft+einer+IPAdresse+ermitteln.html

		$result = mysql_query("SELECT zwei FROM IPtoCountry WHERE name = '" . $Country . "'LIMIT 1");
		
		if(mysql_num_rows($result) == 0) 
			{
			$land = "-";
			} 
		else 
			{
			$row = mysql_fetch_object($result);
			$land = $row->zwei;
			}
	
		return $land;
		}

?>
