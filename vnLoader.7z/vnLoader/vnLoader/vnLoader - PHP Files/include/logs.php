<?php
	//check if included in project
	if ( !defined ( 'vnLoader' ) ) header ( 'location: ../' );

	//set variables
	$usr = $user['name'];

	//include
	include ( './include/function.php' ) ;

	//set where the logfile is
	$file = "./include/logs.log";
	
	if ( instring( '' , $permission ) ) 
		{
		if ( $_POST['clear'] == 'clear' )
			{
			$handle = fopen ( $file , w);
			fwrite ( $handle , "\n");
			fclose ( $handle );
			$page .= '				Logs cleared.' . "\n";
			$page .= '				<br /><br />' . "\n";
			}
		}

	//create a textbox
	$handle = fopen ( $file, r);
	$text = @fread( $handle , filesize( $file ) );
	$text = str_replace ( "<br>" , "\n" , $text );
	fclose ( $handle );

	$page .= '				<form>' . "\n";
	$page .= '<textarea name="logs" style="width: 95%;" rows="30" wrap="off">';
	$page .= $text;
	$page .= '</textarea>' . "\n";
	$page .= '					<br />' . "\n";
	$page .= '				</form>' . "\n";

	if ( instring( '' , $permission ) ) 
		{
		$page .= '				<br />' . "\n";
		$page .= '				<form action="index.php?pid=5" method="post">' . "\n";
		$page .= '					<input type="hidden" name="clear" value="clear" />' . "\n";
		$page .= '					<input type="submit" value="Clear Logs" />' . "\n";
		$page .= '				</form>' . "\n";
		}
?>