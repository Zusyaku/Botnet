<?php
	//check if included in project
	if ( !defined ( 'vnLoader' ) ) header ( 'location: ./' );
	//sql connection
	@mysql_connect("dbserver", "dbusername", "dbpassword");
	@mysql_select_db("dbname");
?>
