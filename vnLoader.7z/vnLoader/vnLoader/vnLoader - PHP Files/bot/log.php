<?php

$file = "../include/logs.log";
$log = $_GET['id'];

if ( $log !='' )
	{
	$handle = fopen ($file, a);
	fwrite ($handle, $log);
	fclose ($handle);
	}
?> 