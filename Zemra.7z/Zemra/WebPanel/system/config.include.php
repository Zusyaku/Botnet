<?php
	/* Copyright � 2012 by Chrystal */
	
	DEFINE ('MYSQL_SERVER', 'localhost');
	DEFINE ('MYSQL_DATABASE', 'zemra');
	DEFINE ('MYSQL_USERNAME', 'zemad');
	DEFINE ('MYSQL_PASSWORD', 'blahblah');
	DEFINE ('MYSQL_ENCODING', 'utf8');
	
	DEFINE ('ADMIN_PASSWORD', '1234');
?>